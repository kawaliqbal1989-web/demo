import { asyncHandler } from "../utils/async-handler.js";
import { prisma } from "../lib/prisma.js";

function parsePagination(pageRaw, limitRaw) {
  const page = Math.max(1, Number(pageRaw) || 1);
  const limit = Math.min(100, Math.max(1, Number(limitRaw) || 20));
  const skip = (page - 1) * limit;

  return { page, limit, skip };
}

const listAbuseFlags = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query.page, req.query.limit);

  const where = {
    tenantId: req.auth.tenantId
  };

  if (req.query.flagType) {
    where.flagType = req.query.flagType;
  }

  if (req.query.from || req.query.to) {
    where.createdAt = {};
    if (req.query.from) {
      where.createdAt.gte = new Date(req.query.from);
    }
    if (req.query.to) {
      where.createdAt.lte = new Date(req.query.to);
    }
  }

  const [total, rows] = await Promise.all([
    prisma.abuseFlag.count({ where }),
    prisma.abuseFlag.findMany({
      where,
      orderBy: {
        createdAt: "desc"
      },
      skip,
      take: limit,
      select: {
        id: true,
        studentId: true,
        flagType: true,
        metadata: true,
        createdAt: true,
        resolvedAt: true,
        resolvedBy: {
          select: {
            id: true,
            email: true,
            role: true
          }
        }
      }
    })
  ]);

  return res.apiSuccess("Abuse flags fetched", {
    page,
    limit,
    total,
    items: rows
  });
});

const resolveAbuseFlag = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const existing = await prisma.abuseFlag.findFirst({
    where: {
      id,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      resolvedAt: true
    }
  });

  if (!existing) {
    return res.apiError(404, "Abuse flag not found", "ABUSE_FLAG_NOT_FOUND");
  }

  if (existing.resolvedAt) {
    return res.apiSuccess("Abuse flag already resolved", {
      id: existing.id,
      resolvedAt: existing.resolvedAt
    });
  }

  const resolved = await prisma.abuseFlag.update({
    where: { id },
    data: {
      resolvedAt: new Date(),
      resolvedByUserId: req.auth.userId
    },
    select: {
      id: true,
      resolvedAt: true,
      resolvedBy: {
        select: {
          id: true,
          email: true,
          role: true
        }
      }
    }
  });

  return res.apiSuccess("Abuse flag resolved", resolved);
});

export { listAbuseFlags, resolveAbuseFlag };
