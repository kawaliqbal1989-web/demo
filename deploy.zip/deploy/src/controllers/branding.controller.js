import { asyncHandler } from "../utils/async-handler.js";
import { resolveBusinessPartnerBrandingForAuth } from "../services/branding.service.js";

const getMyBranding = asyncHandler(async (req, res) => {
  const businessPartner = await resolveBusinessPartnerBrandingForAuth({ auth: req.auth });
  return res.apiSuccess("Branding fetched", {
    businessPartner
  });
});

export { getMyBranding };
