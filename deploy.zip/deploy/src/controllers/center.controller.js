import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";
import { parsePagination } from "../utils/pagination.js";

function fullName(student) {
  const first = String(student?.firstName || "").trim();
  const last = String(student?.lastName || "").trim();
  return [first, last].filter(Boolean).join(" ").trim();
}

function parseISODateOnly(value) {
  const text = String(value || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    return null;
  }
  const date = new Date(`${text}T00:00:00.000Z`);
  if (Number.isNaN(date.getTime())) {
    return null;
  }
  return date;
}

const getCenterMe = asyncHandler(async (req, res) => {
  if (!req.auth?.userId || !req.auth?.tenantId) {
    return res.apiError(401, "Unauthorized", "AUTH_REQUIRED");
  }

  const user = await prisma.authUser.findFirst({
    where: {
      id: req.auth.userId,
      tenantId: req.auth.tenantId,
      role: "CENTER"
    },
    select: {
      id: true,
      username: true,
      email: true,
      isActive: true,
      hierarchyNodeId: true,
      hierarchyNode: { select: { id: true, name: true, code: true, type: true, isActive: true } },
      centerProfile: {
        select: {
          id: true,
          code: true,
          name: true,
          displayName: true,
          status: true,
          isActive: true,
          phonePrimary: true,
          emailOfficial: true,
          logoUrl: true
        }
      }
    }
  });

  if (!user) {
    return res.apiError(404, "Center not found", "CENTER_NOT_FOUND");
  }

  return res.apiSuccess("Center profile fetched", user);
});

const getCenterDashboard = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;

  if (!tenantId || !centerId) {
    return res.apiError(400, "Center scope missing", "CENTER_SCOPE_REQUIRED");
  }

  const now = new Date();
  const since7 = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const [activeStudents, activeTeachers, newAdmissions7d, activeEnrollments] = await Promise.all([
    prisma.student.count({ where: { tenantId, hierarchyNodeId: centerId, isActive: true } }),
    prisma.authUser.count({ where: { tenantId, hierarchyNodeId: centerId, role: "TEACHER", isActive: true } }),
    prisma.student.count({
      where: {
        tenantId,
        hierarchyNodeId: centerId,
        createdAt: { gte: since7 }
      }
    }),
    prisma.enrollment.count({ where: { tenantId, hierarchyNodeId: centerId, status: "ACTIVE" } })
  ]);

  return res.apiSuccess("Center dashboard fetched", {
    activeStudents,
    activeTeachers,
    newAdmissions7d,
    activeEnrollments
  });
});

const listMockTests = asyncHandler(async (req, res) => {
  const { take, skip, orderBy, limit, offset } = parsePagination(req.query);
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;

  if (!tenantId || !centerId) {
    return res.apiError(400, "Center scope missing", "CENTER_SCOPE_REQUIRED");
  }

  const where = {
    tenantId,
    hierarchyNodeId: centerId
  };

  if (req.query.batchId) {
    where.batchId = String(req.query.batchId);
  }

  const [total, items] = await Promise.all([
    prisma.mockTest.count({ where }),
    prisma.mockTest.findMany({
      where,
      take,
      skip,
      orderBy,
      include: {
        batch: { select: { id: true, name: true } },
        worksheet: { select: { id: true, title: true, isPublished: true } }
      }
    })
  ]);

  return res.apiSuccess("Mock tests fetched", { items, total, limit, offset });
});

const getCenterAssignWorksheetsContext = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;
  const studentId = String(req.params.studentId || "").trim();

  if (!tenantId || !centerId) {
    return res.apiError(400, "Center scope missing", "CENTER_SCOPE_REQUIRED");
  }

  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const student = await prisma.student.findFirst({
    where: {
      id: studentId,
      tenantId,
      hierarchyNodeId: centerId
    },
    select: {
      id: true,
      admissionNo: true,
      firstName: true,
      lastName: true,
      levelId: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  const enrollment = await prisma.enrollment.findFirst({
    where: {
      tenantId,
      hierarchyNodeId: centerId,
      studentId: student.id,
      status: "ACTIVE"
    },
    orderBy: { createdAt: "desc" },
    include: {
      level: { select: { id: true, name: true, rank: true } },
      assignedTeacher: { select: { id: true, username: true } }
    }
  });

  const effectiveLevelId = enrollment?.levelId || student.levelId;

  const effectiveLevel = effectiveLevelId
    ? await prisma.level.findFirst({
        where: {
          id: effectiveLevelId,
          tenantId
        },
        select: { id: true, name: true, rank: true }
      })
    : null;

  const teacherProfile = enrollment?.assignedTeacher?.id
    ? await prisma.teacherProfile.findFirst({
        where: {
          tenantId,
          authUserId: enrollment.assignedTeacher.id
        },
        select: { fullName: true }
      })
    : null;

  const worksheets = effectiveLevelId
    ? await prisma.worksheet.findMany({
        where: {
          tenantId,
          levelId: effectiveLevelId
        },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
        select: {
          id: true,
          title: true,
          isPublished: true
        }
      })
    : [];

  const worksheetIds = worksheets.map((w) => w.id);
  const submissions = worksheetIds.length
    ? await prisma.worksheetSubmission.findMany({
        where: {
          tenantId,
          studentId: student.id,
          worksheetId: { in: worksheetIds }
        },
        select: {
          worksheetId: true,
          id: true,
          finalSubmittedAt: true
        }
      })
    : [];

  const assignmentRows = worksheetIds.length
    ? await prisma.worksheetAssignment.findMany({
        where: {
          tenantId,
          studentId: student.id,
          worksheetId: { in: worksheetIds }
        },
        select: {
          worksheetId: true,
          isActive: true,
          assignedAt: true,
          unassignedAt: true
        }
      })
    : [];

  const assignmentByWorksheetId = new Map(assignmentRows.map((r) => [r.worksheetId, r]));
  const assignedWorksheetIds = assignmentRows.filter((r) => r.isActive).map((r) => r.worksheetId);
  const previousAssignedWorksheetIds = assignmentRows.filter((r) => !r.isActive).map((r) => r.worksheetId);
  const assignedById = new Set(assignedWorksheetIds);

  const attemptedByWorksheetId = new Map(submissions.map((s) => [s.worksheetId, 1]));

  const levelRank = enrollment?.level?.rank ?? effectiveLevel?.rank ?? null;
  const courseCode = levelRank ? `AB-L${levelRank}` : null;

  return res.apiSuccess("Assign worksheets context fetched", {
    student: {
      id: student.id,
      fullName: fullName(student),
      studentCode: student.admissionNo
    },
    enrollment: {
      enrollmentId: enrollment?.id || null,
      courseCode,
      levelRank,
      levelTitle: enrollment?.level?.name || effectiveLevel?.name || null,
      courseLevelLabel:
        courseCode && (effectiveLevel?.name || levelRank)
          ? `${courseCode} / ${levelRank ?? ""}`.trim()
          : null,
      assignedTeacherName:
        teacherProfile?.fullName || enrollment?.assignedTeacher?.username || null
    },
    assignedWorksheetIds,
    previousAssignedWorksheetIds,
    worksheets: worksheets.map((w, idx) => {
      const assignment = assignmentByWorksheetId.get(w.id) || null;
      return {
        worksheetId: w.id,
        number: idx + 1,
        title: w.title,
        isPublished: Boolean(w.isPublished),
        attempt: attemptedByWorksheetId.get(w.id) || 0,
        isAssigned: assignedById.has(w.id),
        wasPreviouslyAssigned: Boolean(assignment && !assignment.isActive && assignment.unassignedAt),
        assignedAt: assignment?.assignedAt || null,
        unassignedAt: assignment?.unassignedAt || null
      };
    })
  });
});

const saveCenterWorksheetAssignments = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;
  const studentId = String(req.params.studentId || "").trim();

  if (!tenantId || !centerId) {
    return res.apiError(400, "Center scope missing", "CENTER_SCOPE_REQUIRED");
  }

  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const worksheetIds = Array.isArray(req.body?.worksheetIds)
    ? Array.from(
        new Set(
          req.body.worksheetIds
            .map((v) => String(v).trim())
            .filter(Boolean)
        )
      )
    : [];

  const student = await prisma.student.findFirst({
    where: {
      id: studentId,
      tenantId,
      hierarchyNodeId: centerId
    },
    select: {
      id: true,
      levelId: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  const enrollment = await prisma.enrollment.findFirst({
    where: {
      tenantId,
      hierarchyNodeId: centerId,
      studentId: student.id,
      status: "ACTIVE"
    },
    orderBy: { createdAt: "desc" },
    select: { id: true, levelId: true }
  });

  const effectiveLevelId = enrollment?.levelId || student.levelId;
  if (!effectiveLevelId) {
    return res.apiError(400, "Student level not set", "LEVEL_REQUIRED");
  }

  const allowedWorksheets = worksheetIds.length
    ? await prisma.worksheet.findMany({
        where: {
          tenantId,
          levelId: effectiveLevelId,
          id: { in: worksheetIds }
        },
        select: { id: true }
      })
    : [];

  const allowedIds = allowedWorksheets.map((w) => w.id);
  const now = new Date();

  await prisma.$transaction(async (tx) => {
    await tx.worksheetAssignment.updateMany({
      where: {
        tenantId,
        studentId: student.id,
        isActive: true,
        ...(allowedIds.length ? { worksheetId: { notIn: allowedIds } } : {})
      },
      data: {
        isActive: false,
        unassignedAt: now
      }
    });

    for (const worksheetId of allowedIds) {
      // eslint-disable-next-line no-await-in-loop
      await tx.worksheetAssignment.upsert({
        where: {
          worksheetId_studentId: {
            worksheetId,
            studentId: student.id
          }
        },
        update: {
          tenantId,
          createdByUserId: req.auth.userId,
          isActive: true,
          unassignedAt: null,
          assignedAt: now
        },
        create: {
          tenantId,
          worksheetId,
          studentId: student.id,
          createdByUserId: req.auth.userId,
          isActive: true,
          assignedAt: now,
          unassignedAt: null
        }
      });
    }
  });

  return res.apiSuccess("Assignments saved", {
    studentId,
    assignedCount: allowedIds.length
  });
});

const createMockTest = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;

  const { batchId, worksheetId, title, date, maxMarks } = req.body;

  if (!tenantId || !centerId) {
    return res.apiError(400, "Center scope missing", "CENTER_SCOPE_REQUIRED");
  }

  if (!batchId || !title || !date) {
    return res.apiError(400, "batchId, title, date are required", "VALIDATION_ERROR");
  }

  const parsedDate = parseISODateOnly(date);
  if (!parsedDate) {
    return res.apiError(400, "date must be YYYY-MM-DD", "VALIDATION_ERROR");
  }

  const mm = Number.parseInt(String(maxMarks ?? 0), 10);
  if (!Number.isFinite(mm) || mm <= 0 || mm > 1000) {
    return res.apiError(400, "maxMarks must be a positive integer", "VALIDATION_ERROR");
  }

  const batch = await prisma.batch.findFirst({
    where: { id: String(batchId), tenantId, hierarchyNodeId: centerId },
    select: { id: true }
  });

  if (!batch) {
    return res.apiError(404, "Batch not found", "BATCH_NOT_FOUND");
  }

  let resolvedWorksheetId = null;
  if (worksheetId !== null && worksheetId !== undefined && String(worksheetId).trim()) {
    const worksheet = await prisma.worksheet.findFirst({
      where: {
        id: String(worksheetId).trim(),
        tenantId,
        isPublished: true
      },
      select: { id: true }
    });
    if (!worksheet) {
      return res.apiError(404, "Published worksheet not found", "WORKSHEET_NOT_FOUND");
    }
    resolvedWorksheetId = worksheet.id;
  }

  const created = await prisma.mockTest.create({
    data: {
      tenantId,
      hierarchyNodeId: centerId,
      batchId: String(batchId),
      worksheetId: resolvedWorksheetId,
      title: String(title).trim(),
      date: parsedDate,
      maxMarks: mm,
      createdByUserId: req.auth.userId
    }
  });

  res.locals.entityId = created.id;
  return res.apiSuccess("Mock test created", created, 201);
});

const updateMockTestStatus = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;
  const { id } = req.params;
  const status = String(req.body?.status || "").trim().toUpperCase();

  if (!tenantId || !centerId) {
    return res.apiError(400, "Center scope missing", "CENTER_SCOPE_REQUIRED");
  }

  if (!id) {
    return res.apiError(400, "mock test id is required", "VALIDATION_ERROR");
  }

  const allowed = new Set(["DRAFT", "PUBLISHED", "ARCHIVED"]);
  if (!allowed.has(status)) {
    return res.apiError(400, "status must be one of DRAFT, PUBLISHED, ARCHIVED", "VALIDATION_ERROR");
  }

  const existing = await prisma.mockTest.findFirst({
    where: {
      id,
      tenantId,
      hierarchyNodeId: centerId
    },
    select: { id: true, status: true }
  });

  if (!existing) {
    return res.apiError(404, "Mock test not found", "MOCK_TEST_NOT_FOUND");
  }

  if (existing.status === status) {
    return res.apiSuccess("Mock test status updated", {
      id: existing.id,
      status: existing.status
    });
  }

  const updated = await prisma.mockTest.update({
    where: { id: existing.id },
    data: { status },
    select: {
      id: true,
      status: true
    }
  });

  res.locals.entityId = updated.id;
  return res.apiSuccess("Mock test status updated", updated);
});

const getMockTest = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;
  const { id } = req.params;

  const mockTest = await prisma.mockTest.findFirst({
    where: { id, tenantId, hierarchyNodeId: centerId },
    include: {
      batch: { select: { id: true, name: true } },
      worksheet: { select: { id: true, title: true, isPublished: true } },
      results: {
        include: {
          student: { select: { id: true, admissionNo: true, firstName: true, lastName: true } }
        }
      }
    }
  });

  if (!mockTest) {
    return res.apiError(404, "Mock test not found", "MOCK_TEST_NOT_FOUND");
  }

  const roster = await prisma.enrollment.findMany({
    where: {
      tenantId,
      hierarchyNodeId: centerId,
      batchId: mockTest.batchId,
      status: "ACTIVE"
    },
    include: {
      student: { select: { id: true, admissionNo: true, firstName: true, lastName: true } }
    },
    orderBy: [{ student: { admissionNo: "asc" } }]
  });

  const resultByStudent = new Map((mockTest.results || []).map((r) => [r.studentId, r]));

  return res.apiSuccess("Mock test fetched", {
    ...mockTest,
    roster: roster.map((e) => {
      const existing = resultByStudent.get(e.studentId);
      return {
        studentId: e.studentId,
        student: e.student,
        marks: existing?.marks ?? null
      };
    })
  });
});

const upsertMockTestResults = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const centerId = req.auth.hierarchyNodeId;
  const { id } = req.params;
  const { results } = req.body;

  if (!Array.isArray(results)) {
    return res.apiError(400, "results array is required", "VALIDATION_ERROR");
  }

  const mockTest = await prisma.mockTest.findFirst({
    where: { id, tenantId, hierarchyNodeId: centerId },
    select: { id: true, batchId: true, maxMarks: true, status: true }
  });

  if (!mockTest) {
    return res.apiError(404, "Mock test not found", "MOCK_TEST_NOT_FOUND");
  }

  if (mockTest.status === "ARCHIVED") {
    return res.apiError(409, "Archived mock test cannot be edited", "MOCK_TEST_ARCHIVED");
  }

  const roster = await prisma.enrollment.findMany({
    where: {
      tenantId,
      hierarchyNodeId: centerId,
      batchId: mockTest.batchId,
      status: "ACTIVE"
    },
    select: { studentId: true }
  });

  const allowedStudentIds = new Set(roster.map((r) => r.studentId));

  const cleaned = results
    .map((r) => ({
      studentId: r?.studentId ? String(r.studentId) : "",
      marks: r?.marks === null || r?.marks === undefined ? null : Number.parseInt(String(r.marks), 10)
    }))
    .filter((r) => r.studentId && allowedStudentIds.has(r.studentId));

  let updatedCount = 0;

  await prisma.$transaction(async (tx) => {
    for (const r of cleaned) {
      if (r.marks === null) {
        continue;
      }

      const marks = Math.max(0, Math.min(mockTest.maxMarks, r.marks));

      await tx.mockTestResult.upsert({
        where: { mockTestId_studentId: { mockTestId: mockTest.id, studentId: r.studentId } },
        update: {
          marks,
          recordedByUserId: req.auth.userId,
          recordedAt: new Date()
        },
        create: {
          tenantId,
          mockTestId: mockTest.id,
          studentId: r.studentId,
          marks,
          recordedByUserId: req.auth.userId
        }
      });

      updatedCount += 1;
    }
  });

  return res.apiSuccess("Mock test results saved", { mockTestId: mockTest.id, updatedCount });
});

const listCenterAvailableCourses = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const userId = req.auth.userId;

  // Resolve center → franchise → BP
  const centerProfile = await prisma.centerProfile.findFirst({
    where: { tenantId, authUserId: userId },
    select: {
      franchiseProfile: {
        select: { businessPartnerId: true }
      }
    }
  });

  const businessPartnerId = centerProfile?.franchiseProfile?.businessPartnerId;
  if (!businessPartnerId) {
    return res.apiSuccess("Available courses", []);
  }

  const accesses = await prisma.partnerCourseAccess.findMany({
    where: { businessPartnerId },
    include: {
      course: {
        select: { id: true, code: true, name: true, description: true, isActive: true }
      }
    }
  });

  const courses = accesses
    .map((a) => a.course)
    .filter((c) => c.isActive);

  return res.apiSuccess("Available courses", courses);
});

export {
  getCenterMe,
  getCenterDashboard,
  listCenterAvailableCourses,
  listMockTests,
  createMockTest,
  updateMockTestStatus,
  getMockTest,
  upsertMockTestResults,
  getCenterAssignWorksheetsContext,
  saveCenterWorksheetAssignments
};
