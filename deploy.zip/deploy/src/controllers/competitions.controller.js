import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";
import { recordAudit } from "../utils/audit.js";
import { getCompetitionLeaderboard } from "../services/competition-leaderboard.service.js";
import { createBulkNotification } from "../services/notification.service.js";
import { assertCanModifyOperational } from "../services/ownership-guard.service.js";
import {
  getNextRoleByWorkflowStage,
  transitionForward,
  transitionReject
} from "../services/competition-workflow.service.js";
import { parsePagination } from "../utils/pagination.js";
import { recordCompetitionTransaction } from "../services/financial-ledger.service.js";
import { toCsv } from "../utils/csv.js";

const listCompetitions = asyncHandler(async (req, res) => {
  const { take, skip, orderBy } = parsePagination(req.query);

  const where = {
    tenantId: req.auth.tenantId
  };

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId) {
    where.hierarchyNodeId = req.auth.hierarchyNodeId;
  }

  const data = await prisma.competition.findMany({
    where,
    orderBy,
    skip,
    take,
    include: {
      hierarchyNode: { select: { id: true, name: true, type: true } },
      level: { select: { id: true, name: true, rank: true } },
      createdBy: { select: { id: true, email: true, role: true } },
      enrollments: { select: { studentId: true, rank: true, totalScore: true } },
      worksheets: { select: { worksheetId: true, assignedAt: true } }
    }
  });

  return res.apiSuccess("Competitions fetched", data);
});

const createCompetition = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const {
    title,
    description,
    startsAt,
    endsAt,
    hierarchyNodeId,
    levelId,
  } = req.body;

  const initialStageByRole = {
    CENTER: "CENTER_REVIEW",
    FRANCHISE: "FRANCHISE_REVIEW",
    BP: "BP_REVIEW",
    SUPERADMIN: "SUPERADMIN_APPROVAL"
  };

  const workflowStage = initialStageByRole[req.auth.role] || "CENTER_REVIEW";
  const resolvedHierarchyNodeId = hierarchyNodeId || req.auth.hierarchyNodeId;

  if (!resolvedHierarchyNodeId) {
    return res.apiError(400, "hierarchyNodeId is required", "HIERARCHY_NODE_REQUIRED");
  }

  const created = await prisma.competition.create({
    data: {
      tenantId: req.auth.tenantId,
      title,
      description,
      status: "DRAFT",
      workflowStage,
      startsAt: new Date(startsAt),
      endsAt: new Date(endsAt),
      hierarchyNodeId: resolvedHierarchyNodeId,
      levelId,
      createdByUserId: req.auth.userId
    }
  });

  res.locals.entityId = created.id;
  return res.apiSuccess("Competition created", created, 201);
});

const forwardCompetitionRequest = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const result = await transitionForward({
    tenantId: req.auth.tenantId,
    competitionId: id,
    actorUserId: req.auth.userId,
    actorRole: req.auth.role
  });

  const updated = result.competition;

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "COMPETITION_WORKFLOW_TRANSITION",
    entityType: "COMPETITION",
    entityId: id,
    metadata: {
      from: result.fromStage,
      to: result.toStage,
      action: result.action
    }
  });

  void (async () => {
    try {
      const nextRole = getNextRoleByWorkflowStage(updated.workflowStage);

      if (!nextRole) {
        return;
      }

      const recipients = await prisma.authUser.findMany({
        where: {
          tenantId: req.auth.tenantId,
          isActive: true,
          role: nextRole,
          ...(nextRole === "SUPERADMIN" ? {} : { hierarchyNodeId: updated.hierarchyNodeId })
        },
        select: {
          id: true
        }
      });

      await createBulkNotification(
        recipients.map((recipient) => ({
          tenantId: req.auth.tenantId,
          recipientUserId: recipient.id,
          type: "COMPETITION_STAGE_UPDATE",
          title: "Competition Stage Updated",
          message: `Competition ${updated.title} moved to ${result.toStage}`,
          entityType: "COMPETITION",
          entityId: updated.id
        }))
      );
    } catch {
      return;
    }
  })();

  return res.apiSuccess("Competition request forwarded", updated);
});

const rejectCompetitionRequest = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { reason } = req.body;

  const result = await transitionReject({
    tenantId: req.auth.tenantId,
    competitionId: id,
    actorUserId: req.auth.userId,
    actorRole: req.auth.role,
    reason
  });

  const updated = result.competition;

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "COMPETITION_WORKFLOW_REJECT",
    entityType: "COMPETITION",
    entityId: id,
    metadata: {
      from: result.fromStage,
      to: result.toStage,
      action: result.action
    }
  });

  return res.apiSuccess("Competition request rejected", updated);
});

const getLeaderboard = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { limit } = req.query;

  const leaderboard = await getCompetitionLeaderboard({
    competitionId: id,
    tenantId: req.auth.tenantId,
    limit
  });

  return res.apiSuccess("Competition leaderboard fetched", leaderboard);
});

const exportCompetitionResultsCsv = asyncHandler(async (req, res) => {
  const { id: competitionId } = req.params;

  const competition = await prisma.competition.findFirst({
    where: {
      id: competitionId,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      title: true
    }
  });

  if (!competition) {
    return res.apiError(404, "Competition not found", "COMPETITION_NOT_FOUND");
  }

  const enrollments = await prisma.competitionEnrollment.findMany({
    where: {
      tenantId: req.auth.tenantId,
      competitionId
    },
    orderBy: [{ rank: "asc" }, { enrolledAt: "asc" }],
    select: {
      enrolledAt: true,
      rank: true,
      totalScore: true,
      student: {
        select: {
          id: true,
          admissionNo: true,
          firstName: true,
          lastName: true
        }
      }
    }
  });

  const csv = toCsv({
    headers: [
      "competitionId",
      "competitionTitle",
      "studentId",
      "admissionNo",
      "studentName",
      "rank",
      "totalScore",
      "enrolledAt"
    ],
    rows: enrollments.map((e) => [
      competition.id,
      competition.title,
      e.student.id,
      e.student.admissionNo,
      `${e.student.firstName} ${e.student.lastName}`,
      e.rank ?? "",
      e.totalScore !== null && e.totalScore !== undefined ? String(e.totalScore) : "",
      e.enrolledAt?.toISOString?.() || String(e.enrolledAt)
    ])
  });

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader(
    "Content-Disposition",
    `attachment; filename=competition_${competition.id}_results.csv`
  );
  return res.status(200).send(csv);
});

const enrollStudent = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id: competitionId } = req.params;
  const { studentId, competitionFeeAmount } = req.body;

  if (!studentId) {
    return res.apiError(400, "studentId is required", "STUDENT_ID_REQUIRED");
  }

  const created = await prisma.$transaction(async (tx) => {
    const competition = await tx.competition.findFirst({
      where: {
        id: competitionId,
        tenantId: req.auth.tenantId
      },
      select: {
        id: true
      }
    });

    if (!competition) {
      const error = new Error("Competition not found");
      error.statusCode = 404;
      error.errorCode = "COMPETITION_NOT_FOUND";
      throw error;
    }

    const student = await tx.student.findFirst({
      where: {
        id: studentId,
        tenantId: req.auth.tenantId
      },
      select: {
        id: true
      }
    });

    if (!student) {
      const error = new Error("Student not found");
      error.statusCode = 404;
      error.errorCode = "STUDENT_NOT_FOUND";
      throw error;
    }

    const existing = await tx.competitionEnrollment.findFirst({
      where: {
        competitionId,
        studentId,
        tenantId: req.auth.tenantId,
        isActive: true
      },
      select: {
        competitionId: true
      }
    });

    if (existing) {
      const error = new Error("Duplicate active enrollment is not allowed");
      error.statusCode = 409;
      error.errorCode = "DUPLICATE_ACTIVE_ENROLLMENT";
      throw error;
    }

    const enrollment = await tx.competitionEnrollment.create({
      data: {
        competitionId,
        studentId,
        tenantId: req.auth.tenantId,
        isActive: true
      }
    });

    await recordCompetitionTransaction({
      tx,
      tenantId: req.auth.tenantId,
      competitionId,
      studentId,
      actorUserId: req.auth.userId,
      grossAmount: competitionFeeAmount ?? 0
    });

    return enrollment;
  });

  return res.apiSuccess("Student enrolled", created, 201);
});

export {
  listCompetitions,
  createCompetition,
  forwardCompetitionRequest,
  rejectCompetitionRequest,
  getLeaderboard,
  exportCompetitionResultsCsv,
  enrollStudent
};
