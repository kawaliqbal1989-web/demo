import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";

const getHealth = asyncHandler(async (_req, res) => {
  try {
    // Lightweight DB ping for shared-hosting safety.
    await prisma.$queryRaw`SELECT 1`;
    return res.status(200).json({
      success: true,
      message: "ok",
      data: {
        status: "ok",
        db: "ok",
        timestamp: new Date().toISOString()
      },
      error_code: null
    });
  } catch (_err) {
    return res.status(503).json({
      success: false,
      message: "unhealthy",
      data: {
        status: "degraded",
        db: "down",
        timestamp: new Date().toISOString()
      },
      error_code: "HEALTHCHECK_DB_FAILED"
    });
  }
});

export { getHealth };
