import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";
import { assertCanModifyOperational } from "../services/ownership-guard.service.js";
import { parsePagination } from "../utils/pagination.js";

const listHierarchyNodes = asyncHandler(async (req, res) => {
  const { take, skip, orderBy } = parsePagination(req.query);
  const includeInactive = req.query.includeInactive === "1" || req.query.includeInactive === "true";

  const where = {
    tenantId: req.auth.tenantId,
    ...(includeInactive ? {} : { isActive: true })
  };

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId) {
    where.id = req.auth.hierarchyNodeId;
  }

  const data = await prisma.hierarchyNode.findMany({
    where,
    orderBy,
    skip,
    take,
    include: {
      parent: { select: { id: true, name: true, type: true } }
    }
  });

  return res.apiSuccess("Hierarchy nodes fetched", data);
});

const createHierarchyNode = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { name, code, type, parentId } = req.body;

  const created = await prisma.hierarchyNode.create({
    data: {
      tenantId: req.auth.tenantId,
      name,
      code,
      type,
      parentId
    }
  });

  res.locals.entityId = created.id;
  return res.apiSuccess("Hierarchy node created", created, 201);
});

export { listHierarchyNodes, createHierarchyNode };
