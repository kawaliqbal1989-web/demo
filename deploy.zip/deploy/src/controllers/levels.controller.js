import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";
import { generateWorksheet } from "../services/abacus-question-generator.service.js";
import { assertCanModifyAcademic, assertCanModifyOperational } from "../services/ownership-guard.service.js";

const listLevels = asyncHandler(async (req, res) => {
  const data = await prisma.level.findMany({
    where: {
      tenantId: req.auth.tenantId
    },
    orderBy: { rank: "asc" }
  });

  return res.apiSuccess("Levels fetched", data);
});

const createLevel = asyncHandler(async (req, res) => {
  assertCanModifyAcademic(req.auth.role);

  const { name, rank, description } = req.body;

  const created = await prisma.level.create({
    data: {
      tenantId: req.auth.tenantId,
      name,
      rank,
      description
    }
  });

  res.locals.entityId = created.id;
  return res.apiSuccess("Level created", created, 201);
});

const generateLevelWorksheet = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id: levelId } = req.params;
  const mode = String(req.query.mode || "practice").toLowerCase();
  const seed = req.query.seed ? String(req.query.seed) : null;

  if (!["practice", "exam"].includes(mode)) {
    return res.apiError(400, "Invalid mode. Use practice or exam", "INVALID_MODE");
  }

  if (mode === "exam" && !seed) {
    return res.apiError(400, "Seed is required in exam mode", "SEED_REQUIRED");
  }

  const level = await prisma.level.findFirst({
    where: {
      id: levelId,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      rank: true,
      name: true
    }
  });

  if (!level) {
    return res.apiError(404, "Level not found", "LEVEL_NOT_FOUND");
  }

  const seedToUse = seed || `${Date.now()}-${req.auth.userId}-${levelId}`;
  const generated = await generateWorksheet(levelId, req.auth.tenantId, seedToUse);

  const created = await prisma.$transaction(async (tx) => {
    const worksheet = await tx.worksheet.create({
      data: {
        tenantId: req.auth.tenantId,
        title: `${level.name} Generated Worksheet`,
        description: `Auto-generated worksheet for ${level.name}`,
        difficulty: level.rank <= 2 ? "EASY" : level.rank <= 4 ? "MEDIUM" : "HARD",
        levelId,
        createdByUserId: req.auth.userId,
        isPublished: false,
        templateId: generated.templateId,
        generationMode: mode === "exam" ? "EXAM" : "PRACTICE",
        generationSeed: mode === "exam" ? seedToUse : null,
        generatedAt: new Date(),
        timeLimitSeconds: generated.timeLimitSeconds
      }
    });

    await tx.worksheetQuestion.createMany({
      data: generated.questions.map((question) => ({
        tenantId: req.auth.tenantId,
        worksheetId: worksheet.id,
        questionNumber: question.questionNumber,
        questionBankId: question.questionBankId,
        operands: question.operands,
        operation: question.operation,
        correctAnswer: question.correctAnswer
      }))
    });

    return worksheet;
  });

  return res.apiSuccess("Worksheet generated", {
    worksheetId: created.id,
    questions: generated.questions.map((question) => ({
      questionNumber: question.questionNumber,
      operands: question.operands,
      operation: question.operation
    }))
  }, 201);
});

export { listLevels, createLevel, generateLevelWorksheet };
