import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";
import { recordAudit } from "../utils/audit.js";
import { hashPassword } from "../utils/password.js";
import crypto from "crypto";
import { getLevelPerformance } from "../services/student-performance.service.js";
import { createBulkNotification } from "../services/notification.service.js";
import { recordStudentPaymentTransaction } from "../services/financial-ledger.service.js";
import { assertCanModifyOperational } from "../services/ownership-guard.service.js";
import {
  assignLevelWithIntegrity,
  evaluatePassThreshold,
  validateInitialStudentLevel
} from "../services/student-lifecycle.service.js";
import { parsePagination } from "../utils/pagination.js";
import { recordEnrollmentTransaction } from "../services/financial-ledger.service.js";
import { toCsv } from "../utils/csv.js";

function parseIsoDateOnly(value) {
  if (!value) return null;
  const text = String(value).trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) {
    const err = new Error("Invalid date format. Use YYYY-MM-DD");
    err.statusCode = 400;
    err.errorCode = "VALIDATION_ERROR";
    throw err;
  }
  return new Date(`${text}T00:00:00.000Z`);
}

function normalizeNoteTags(tags) {
  if (tags === undefined) return undefined;
  if (tags === null) return null;
  if (Array.isArray(tags)) return tags;
  if (tags && typeof tags === "object") return tags;
  return null;
}

function normalizeActiveStatus(value) {
  if (value === undefined || value === null || value === "") {
    return null;
  }

  const normalized = String(value).trim().toUpperCase();
  if (normalized === "ACTIVE") return true;
  if (normalized === "INACTIVE") return false;
  return null;
}

function isUniqueConstraintError(error) {
  const code = error?.code ? String(error.code) : "";
  return code === "P2002";
}

function makeApiError(statusCode, message, errorCode) {
  const err = new Error(message);
  err.statusCode = statusCode;
  err.errorCode = errorCode;
  return err;
}

function getUniqueConstraintTargets(error) {
  const target = error?.meta?.target;
  if (!target) return [];
  if (Array.isArray(target)) return target.map((t) => String(t));
  return [String(target)];
}

function uniqueTargetsInclude(error, needle) {
  const targets = getUniqueConstraintTargets(error)
    .join("|")
    .toLowerCase();
  return targets.includes(String(needle).toLowerCase());
}

function makeStudentPlaceholderEmail({ tenantId, studentId }) {
  const safeTenant = String(tenantId || "tenant").replace(/[^a-zA-Z0-9]/g, "").slice(0, 24) || "tenant";
  const safeStudent = String(studentId || "student").replace(/[^a-zA-Z0-9]/g, "").slice(0, 32) || "student";
  return `no-email+${safeTenant}.${safeStudent}@abacus.invalid`;
}

function isAdmissionNoUniqueCollision(error) {
  if (!isUniqueConstraintError(error)) return false;
  return uniqueTargetsInclude(error, "admissionNo") || uniqueTargetsInclude(error, "admissionno");
}

function isStudentEmailUniqueCollision(error) {
  if (!isUniqueConstraintError(error)) return false;
  // Student has @@unique([tenantId, email])
  return uniqueTargetsInclude(error, "email");
}

function normalizeAdmissionNo(value) {
  const trimmed = String(value || "").trim();
  return trimmed.length ? trimmed : null;
}

function normalizeMoney(value) {
  if (value === undefined) return undefined;
  if (value === null || value === "") return null;
  const num = Number(value);
  if (!Number.isFinite(num) || num < 0) {
    return { error: "Amount must be a non-negative number" };
  }
  return Number(num.toFixed(2));
}

function parseStudentCodeNumeric(code, prefix) {
  const text = String(code || "").trim();
  const re = new RegExp(`^${prefix}(\\d+)$`);
  const match = text.match(re);
  if (!match) return null;
  const num = Number(match[1]);
  if (!Number.isInteger(num) || num < 0) return null;
  return { num, width: Math.max(4, match[1].length) };
}

function formatStudentCode(prefix, num, width) {
  return `${prefix}${String(num).padStart(width, "0")}`;
}

function generateTempPassword() {
  return crypto.randomBytes(12).toString("base64url");
}

async function generateNextStudentCode({ tx, tenantId, prefix = "ST" }) {
  const normalizedPrefix = String(prefix || "").trim();
  if (!/^[A-Z]{1,8}$/.test(normalizedPrefix)) {
    throw new Error("Invalid student code prefix");
  }

  const startIndex = normalizedPrefix.length + 1; // MySQL SUBSTRING is 1-indexed
  const regex = `^${normalizedPrefix}[0-9]+$`;

  const toSafeNumber = (value) => {
    if (value === null || value === undefined) return 0;
    if (typeof value === "bigint") return Number(value);
    const num = Number(value);
    return Number.isFinite(num) ? num : 0;
  };

  const [studentAgg, userAgg] = await Promise.all([
    tx.$queryRaw`
      SELECT
        MAX(CAST(SUBSTRING(admissionNo, ${startIndex}) AS UNSIGNED)) AS maxNum,
        MAX(CHAR_LENGTH(SUBSTRING(admissionNo, ${startIndex}))) AS maxWidth
      FROM Student
      WHERE tenantId = ${tenantId}
        AND admissionNo REGEXP ${regex}
    `,
    tx.$queryRaw`
      SELECT
        MAX(CAST(SUBSTRING(username, ${startIndex}) AS UNSIGNED)) AS maxNum,
        MAX(CHAR_LENGTH(SUBSTRING(username, ${startIndex}))) AS maxWidth
      FROM AuthUser
      WHERE tenantId = ${tenantId}
        AND username REGEXP ${regex}
    `
  ]);

  const studentRow = Array.isArray(studentAgg) ? studentAgg[0] : null;
  const userRow = Array.isArray(userAgg) ? userAgg[0] : null;

  const maxNum = Math.max(toSafeNumber(studentRow?.maxNum), toSafeNumber(userRow?.maxNum));
  const nextNum = maxNum + 1;

  const width = Math.max(
    4,
    toSafeNumber(studentRow?.maxWidth),
    toSafeNumber(userRow?.maxWidth),
    String(nextNum).length
  );

  return formatStudentCode(normalizedPrefix, nextNum, width);
}

const getNextStudentCode = asyncHandler(async (req, res) => {
  // Preview only; final allocation happens during createStudent with collision retries.
  const code = await prisma.$transaction(async (tx) => {
    return generateNextStudentCode({ tx, tenantId: req.auth.tenantId, prefix: "ST" });
  });

  return res.apiSuccess("Next student code", { admissionNo: code });
});

const listStudents = asyncHandler(async (req, res) => {
  const { take, skip, orderBy } = parsePagination(req.query);

  const where = {
    tenantId: req.auth.tenantId
  };

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId) {
    where.hierarchyNodeId = req.auth.hierarchyNodeId;
  }

  const q = req.query.q ? String(req.query.q).trim() : "";
  if (q) {
    where.OR = [
      { admissionNo: { contains: q } },
      { firstName: { contains: q } },
      { lastName: { contains: q } }
    ];
  }

  const active = normalizeActiveStatus(req.query.status);
  if (active !== null) {
    where.isActive = active;
  }

  if (req.query.levelId) {
    where.levelId = String(req.query.levelId);
  }

  const teacherUserId = req.query.teacherUserId ? String(req.query.teacherUserId) : "";
  if (teacherUserId) {
    where.batchEnrollments = {
      some: {
        status: "ACTIVE",
        assignedTeacherUserId: teacherUserId
      }
    };
  }

  const courseCode = req.query.courseCode ? String(req.query.courseCode).trim() : "";
  if (courseCode) {
    where.level = {
      is: {
        name: { contains: courseCode }
      }
    };
  }

  const data = await prisma.student.findMany({
    where,
    orderBy,
    skip,
    take,
    include: {
      hierarchyNode: { select: { id: true, name: true, type: true } },
      level: { select: { id: true, name: true, rank: true } },
      course: { select: { id: true, code: true, name: true } },
      assignedCourses: {
        select: {
          id: true,
          courseId: true,
          course: { select: { id: true, code: true, name: true } }
        }
      },
      currentTeacher: {
        select: {
          id: true,
          username: true,
          email: true,
          teacherProfile: { select: { fullName: true } }
        }
      },
      authUsers: { select: { id: true, username: true, email: true, isActive: true, role: true } },
      batchEnrollments: {
        where: { status: "ACTIVE" },
        orderBy: { createdAt: "desc" },
        take: 1,
        include: {
          batch: { select: { id: true, name: true } },
          assignedTeacher: {
            select: {
              id: true,
              username: true,
              email: true,
              teacherProfile: { select: { fullName: true } }
            }
          }
        }
      }
    }
  });

  return res.apiSuccess("Students fetched", data);
});

const getStudent = asyncHandler(async (req, res) => {
  const studentId = String(req.params.id || "").trim();
  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const where = {
    id: studentId,
    tenantId: req.auth.tenantId
  };

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId) {
    where.hierarchyNodeId = req.auth.hierarchyNodeId;
  }

  const student = await prisma.student.findFirst({
    where,
    include: {
      hierarchyNode: { select: { id: true, name: true, type: true } },
      level: { select: { id: true, name: true, rank: true } },
      course: { select: { id: true, code: true, name: true } },
      assignedCourses: {
        select: {
          id: true,
          courseId: true,
          course: { select: { id: true, code: true, name: true } }
        }
      },
      currentTeacher: {
        select: {
          id: true,
          username: true,
          email: true,
          teacherProfile: { select: { fullName: true } }
        }
      },
      authUsers: { select: { id: true, username: true, email: true, isActive: true, role: true } },
      batchEnrollments: {
        where: { status: "ACTIVE" },
        orderBy: { createdAt: "desc" },
        take: 1,
        include: {
          batch: { select: { id: true, name: true } },
          assignedTeacher: {
            select: {
              id: true,
              username: true,
              email: true,
              teacherProfile: { select: { fullName: true } }
            }
          }
        }
      }
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  return res.apiSuccess("Student fetched", student);
});

const listStudentNotes = asyncHandler(async (req, res) => {
  const { take, skip, orderBy, limit, offset } = parsePagination(req.query);

  const studentId = String(req.params.id);
  const scopeEntity = req.scopeEntity;
  const tenantId = scopeEntity?.tenantId || req.auth.tenantId;
  const hierarchyNodeId = scopeEntity?.hierarchyNodeId || null;

  const q = req.query.q ? String(req.query.q).trim() : "";
  const from = req.query.from ? parseIsoDateOnly(req.query.from) : null;
  const to = req.query.to ? parseIsoDateOnly(req.query.to) : null;

  const where = {
    tenantId,
    studentId,
    isDeleted: false,
    ...(hierarchyNodeId ? { hierarchyNodeId } : {}),
    ...(q ? { note: { contains: q } } : {}),
    ...(from || to
      ? {
          createdAt: {
            ...(from ? { gte: from } : {}),
            ...(to ? { lte: new Date(to.getTime() + 24 * 60 * 60 * 1000 - 1) } : {})
          }
        }
      : {})
  };

  const [total, items] = await Promise.all([
    prisma.teacherNote.count({ where }),
    prisma.teacherNote.findMany({
      where,
      take,
      skip,
      orderBy,
      select: {
        id: true,
        note: true,
        tags: true,
        createdAt: true,
        updatedAt: true,
        teacher: {
          select: {
            id: true,
            username: true,
            email: true,
            role: true,
            teacherProfile: { select: { fullName: true } }
          }
        }
      }
    })
  ]);

  return res.apiSuccess("Student notes", {
    items,
    total,
    limit,
    offset
  });
});

const createStudentNote = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const studentId = String(req.params.id || "").trim();
  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const note = req.body?.note;
  const tags = req.body?.tags;

  if (!note || !String(note).trim()) {
    return res.apiError(400, "note is required", "VALIDATION_ERROR");
  }

  const student = await prisma.student.findFirst({
    where: { id: studentId, tenantId: req.auth.tenantId },
    select: { id: true, hierarchyNodeId: true }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  if (req.auth.role === "CENTER" && req.auth.hierarchyNodeId && student.hierarchyNodeId !== req.auth.hierarchyNodeId) {
    return res.apiError(403, "Forbidden", "ROLE_FORBIDDEN");
  }

  const created = await prisma.teacherNote.create({
    data: {
      tenantId: req.auth.tenantId,
      hierarchyNodeId: student.hierarchyNodeId,
      teacherUserId: req.auth.userId,
      studentId: student.id,
      note: String(note).trim(),
      ...(tags !== undefined ? { tags: normalizeNoteTags(tags) } : {})
    }
  });

  res.locals.entityId = created.id;
  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "STUDENT_NOTE_CREATE",
    entityType: "TEACHER_NOTE",
    entityId: created.id,
    metadata: { studentId: student.id }
  });

  return res.apiSuccess("Note created", created, 201);
});

const updateStudentNote = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const noteId = String(req.params.noteId || "").trim();
  if (!noteId) {
    return res.apiError(400, "noteId is required", "VALIDATION_ERROR");
  }

  const existing = await prisma.teacherNote.findFirst({
    where: {
      id: noteId,
      tenantId: req.auth.tenantId,
      isDeleted: false,
      ...(req.auth.role === "CENTER" && req.auth.hierarchyNodeId ? { hierarchyNodeId: req.auth.hierarchyNodeId } : {})
    },
    select: { id: true }
  });

  if (!existing) {
    return res.apiError(404, "Note not found", "NOTE_NOT_FOUND");
  }

  const note = req.body?.note;
  const tags = req.body?.tags;

  const updated = await prisma.teacherNote.update({
    where: { id: existing.id },
    data: {
      ...(note !== undefined ? { note: String(note || "").trim() } : {}),
      ...(tags !== undefined ? { tags: normalizeNoteTags(tags) } : {})
    }
  });

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "STUDENT_NOTE_UPDATE",
    entityType: "TEACHER_NOTE",
    entityId: updated.id
  });

  return res.apiSuccess("Note updated", updated);
});

const deleteStudentNote = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const noteId = String(req.params.noteId || "").trim();
  if (!noteId) {
    return res.apiError(400, "noteId is required", "VALIDATION_ERROR");
  }

  const existing = await prisma.teacherNote.findFirst({
    where: {
      id: noteId,
      tenantId: req.auth.tenantId,
      isDeleted: false,
      ...(req.auth.role === "CENTER" && req.auth.hierarchyNodeId ? { hierarchyNodeId: req.auth.hierarchyNodeId } : {})
    },
    select: { id: true }
  });

  if (!existing) {
    return res.apiError(404, "Note not found", "NOTE_NOT_FOUND");
  }

  const updated = await prisma.teacherNote.update({
    where: { id: existing.id },
    data: {
      isDeleted: true,
      deletedAt: new Date()
    }
  });

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "STUDENT_NOTE_DELETE",
    entityType: "TEACHER_NOTE",
    entityId: updated.id
  });

  return res.apiSuccess("Note deleted", null);
});

const exportStudentNotesCsv = asyncHandler(async (req, res) => {
  const studentId = String(req.params.id || "").trim();
  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const q = req.query.q ? String(req.query.q).trim() : "";
  const from = req.query.from ? parseIsoDateOnly(req.query.from) : null;
  const to = req.query.to ? parseIsoDateOnly(req.query.to) : null;

  const student = await prisma.student.findFirst({
    where: { id: studentId, tenantId: req.auth.tenantId },
    select: { id: true, admissionNo: true, hierarchyNodeId: true }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  if (req.auth.role === "CENTER" && req.auth.hierarchyNodeId && student.hierarchyNodeId !== req.auth.hierarchyNodeId) {
    return res.apiError(403, "Forbidden", "ROLE_FORBIDDEN");
  }

  const where = {
    tenantId: req.auth.tenantId,
    studentId: student.id,
    isDeleted: false,
    ...(req.auth.role === "CENTER" && req.auth.hierarchyNodeId ? { hierarchyNodeId: req.auth.hierarchyNodeId } : {}),
    ...(q ? { note: { contains: q } } : {}),
    ...(from || to
      ? {
          createdAt: {
            ...(from ? { gte: from } : {}),
            ...(to ? { lte: new Date(to.getTime() + 24 * 60 * 60 * 1000 - 1) } : {})
          }
        }
      : {})
  };

  const notes = await prisma.teacherNote.findMany({
    where,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    select: {
      id: true,
      note: true,
      tags: true,
      createdAt: true,
      updatedAt: true,
      teacher: {
        select: {
          id: true,
          username: true,
          email: true,
          teacherProfile: { select: { fullName: true } }
        }
      }
    }
  });

  const csv = toCsv({
    headers: ["createdAt", "updatedAt", "author", "note", "tags"],
    rows: notes.map((n) => {
      const author = n?.teacher?.teacherProfile?.fullName || n?.teacher?.username || n?.teacher?.email || "";
      return [
        n.createdAt?.toISOString?.() || String(n.createdAt),
        n.updatedAt?.toISOString?.() || String(n.updatedAt),
        author,
        n.note,
        n.tags != null ? JSON.stringify(n.tags) : ""
      ];
    })
  });

  const safeName = (student.admissionNo || student.id || "student").replace(/[^a-zA-Z0-9_-]/g, "_");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename=${safeName}-notes.csv`);
  return res.status(200).send(csv);
});

const exportStudentsCsv = asyncHandler(async (req, res) => {
  const { take, skip, orderBy } = parsePagination(req.query);
  const safeTake = Math.min(take, 5000);

  const where = {
    tenantId: req.auth.tenantId
  };

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId) {
    where.hierarchyNodeId = req.auth.hierarchyNodeId;
  }

  const students = await prisma.student.findMany({
    where,
    orderBy,
    skip,
    take: safeTake,
    select: {
      admissionNo: true,
      firstName: true,
      lastName: true,
      email: true,
      isActive: true,
      createdAt: true,
      hierarchyNode: { select: { id: true, name: true, type: true } },
      level: { select: { id: true, name: true, rank: true } }
    }
  });

  const csv = toCsv({
    headers: [
      "admissionNo",
      "firstName",
      "lastName",
      "email",
      "level",
      "levelRank",
      "centerName",
      "centerType",
      "isActive",
      "createdAt"
    ],
    rows: students.map((s) => [
      s.admissionNo,
      s.firstName,
      s.lastName,
      s.email || "",
      s.level?.name || "",
      s.level?.rank ?? "",
      s.hierarchyNode?.name || "",
      s.hierarchyNode?.type || "",
      s.isActive ? "true" : "false",
      s.createdAt?.toISOString?.() || String(s.createdAt)
    ])
  });

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=students.csv");
  return res.status(200).send(csv);
});

const createStudent = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const {
    admissionNo,
    firstName,
    lastName,
    gender,
    email,
    dateOfBirth,
    hierarchyNodeId: requestedHierarchyNodeId,
    levelId: requestedLevelId,
    guardianName,
    guardianPhone,
    guardianEmail,
    phonePrimary,
    phoneSecondary,
    address,
    state,
    district,
    tehsil,
    totalFeeAmount,
    admissionFeeAmount,
    currentTeacherUserId,
    isActive,
    createLoginAccount,
    loginPassword,
    enrollmentFeeAmount
  } = req.body;

  const normalizedTotalFeeAmount = normalizeMoney(totalFeeAmount);
  if (normalizedTotalFeeAmount?.error) {
    return res.apiError(400, normalizedTotalFeeAmount.error, "VALIDATION_ERROR");
  }
  const normalizedAdmissionFeeAmount = normalizeMoney(admissionFeeAmount);
  if (normalizedAdmissionFeeAmount?.error) {
    return res.apiError(400, normalizedAdmissionFeeAmount.error, "VALIDATION_ERROR");
  }

  const hierarchyNodeId = req.auth.role === "SUPERADMIN"
    ? String(requestedHierarchyNodeId || "")
    : String(req.auth.hierarchyNodeId || "");

  if (!hierarchyNodeId) {
    return res.apiError(400, "hierarchyNodeId is required", "HIERARCHY_NODE_REQUIRED");
  }

  const resolvedLevelId = requestedLevelId
    ? String(requestedLevelId)
    : (
      await prisma.level.findFirst({
        where: { tenantId: req.auth.tenantId },
        orderBy: { rank: "asc" },
        select: { id: true }
      })
    )?.id;

  if (!resolvedLevelId) {
    return res.apiError(400, "No levels configured for tenant", "LEVELS_MISSING");
  }

  // Student email is optional; username/password login works without email.

  const normalizedGender = gender ? String(gender).trim().toUpperCase() : null;
  if (normalizedGender && !["MALE", "FEMALE", "OTHER"].includes(normalizedGender)) {
    return res.apiError(400, "gender must be MALE, FEMALE, or OTHER", "VALIDATION_ERROR");
  }

  const requestedAdmissionNo = normalizeAdmissionNo(admissionNo);
  const shouldAutoGenerateAdmissionNo = req.auth.role === "CENTER" && !requestedAdmissionNo;

  if (!shouldAutoGenerateAdmissionNo && !requestedAdmissionNo) {
    return res.apiError(400, "admissionNo is required", "STUDENT_CODE_REQUIRED");
  }

  const shouldCreateLogin = Boolean(createLoginAccount);

  if (shouldCreateLogin && !loginPassword && shouldAutoGenerateAdmissionNo === false && !requestedAdmissionNo) {
    return res.apiError(400, "loginPassword (or admissionNo) is required to create login", "STUDENT_PASSWORD_REQUIRED");
  }

  const created = await prisma.$transaction(async (tx) => {
    await validateInitialStudentLevel({
      tx,
      tenantId: req.auth.tenantId,
      levelId: resolvedLevelId
    });

    let resolvedCurrentTeacherUserId = currentTeacherUserId ? String(currentTeacherUserId) : null;
    if (resolvedCurrentTeacherUserId) {
      const teacher = await tx.authUser.findFirst({
        where: {
          tenantId: req.auth.tenantId,
          id: resolvedCurrentTeacherUserId,
          role: "TEACHER",
          isActive: true,
          hierarchyNodeId
        },
        select: { id: true }
      });

      if (!teacher) {
        return res.apiError(400, "currentTeacherUserId is not a valid active teacher for this center", "TEACHER_NOT_FOUND");
      }
    }

    let finalAdmissionNo = shouldAutoGenerateAdmissionNo
      ? await generateNextStudentCode({ tx, tenantId: req.auth.tenantId, prefix: "ST" })
      : requestedAdmissionNo;

    // If client did not send loginPassword, default to the final admissionNo.
    const tempPassword = shouldCreateLogin ? String(loginPassword || finalAdmissionNo || "").trim() : null;
    if (shouldCreateLogin && !tempPassword) {
      return res.apiError(400, "loginPassword (or admissionNo) is required to create login", "STUDENT_PASSWORD_REQUIRED");
    }

    // Create student with retry on admissionNo collisions (tenantId+admissionNo is unique).
    let student = null;
    for (let attempt = 0; attempt < 8; attempt += 1) {
      try {
        // eslint-disable-next-line no-await-in-loop
        student = await tx.student.create({
          data: {
            tenantId: req.auth.tenantId,
            admissionNo: finalAdmissionNo,
            firstName,
            lastName,
            gender: normalizedGender || null,
            email,
            dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
            hierarchyNodeId,
            levelId: resolvedLevelId,
            guardianName: guardianName ? String(guardianName) : null,
            guardianPhone: guardianPhone ? String(guardianPhone) : null,
            guardianEmail: guardianEmail ? String(guardianEmail) : null,
            phonePrimary: phonePrimary ? String(phonePrimary) : null,
            phoneSecondary: phoneSecondary ? String(phoneSecondary) : null,
            address: address ? String(address) : null,
            state: state ? String(state) : null,
            district: district ? String(district) : null,
            tehsil: tehsil ? String(tehsil) : null,
            ...(normalizedTotalFeeAmount !== undefined ? { totalFeeAmount: normalizedTotalFeeAmount } : {}),
            ...(normalizedAdmissionFeeAmount !== undefined ? { admissionFeeAmount: normalizedAdmissionFeeAmount } : {}),
            currentTeacherUserId: resolvedCurrentTeacherUserId,
            ...(isActive !== undefined ? { isActive: Boolean(isActive) } : {})
          }
        });
        break;
      } catch (err) {
        if (!isUniqueConstraintError(err)) {
          throw err;
        }

        // If email is duplicated, do NOT retry (changing admissionNo won't help).
        if (isStudentEmailUniqueCollision(err)) {
          throw makeApiError(409, "Student email already exists", "STUDENT_EMAIL_EXISTS");
        }

        // Only retry on admissionNo collisions when we are auto-generating.
        if (!shouldAutoGenerateAdmissionNo || !isAdmissionNoUniqueCollision(err)) {
          throw err;
        }

        // eslint-disable-next-line no-await-in-loop
        finalAdmissionNo = await generateNextStudentCode({ tx, tenantId: req.auth.tenantId, prefix: "ST" });
      }
    }

    if (!student) {
      // Fallback: try creating with a timestamp-randomized admissionNo to avoid blocking
      const fallbackAdmissionNo = `${String(finalAdmissionNo || "ST").slice(0, 16)}${Date.now()}${Math.floor(Math.random() * 10000)}`;
      try {
        student = await tx.student.create({
          data: {
            tenantId: req.auth.tenantId,
            admissionNo: fallbackAdmissionNo,
            firstName,
            lastName,
            gender: normalizedGender || null,
            email,
            dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
            hierarchyNodeId,
            levelId: resolvedLevelId,
            guardianName: guardianName ? String(guardianName) : null,
            guardianPhone: guardianPhone ? String(guardianPhone) : null,
            phonePrimary: phonePrimary ? String(phonePrimary) : null,
            phoneSecondary: phoneSecondary ? String(phoneSecondary) : null,
            address: address ? String(address) : null,
            state: state ? String(state) : null,
            district: district ? String(district) : null,
            tehsil: tehsil ? String(tehsil) : null,
            ...(normalizedTotalFeeAmount !== undefined ? { totalFeeAmount: normalizedTotalFeeAmount } : {}),
            ...(normalizedAdmissionFeeAmount !== undefined ? { admissionFeeAmount: normalizedAdmissionFeeAmount } : {}),
            currentTeacherUserId: resolvedCurrentTeacherUserId,
            ...(isActive !== undefined ? { isActive: Boolean(isActive) } : {})
          }
        });
      } catch (err) {
        if (isStudentEmailUniqueCollision(err)) {
          throw makeApiError(409, "Student email already exists", "STUDENT_EMAIL_EXISTS");
        }
        throw makeApiError(503, "Unable to allocate a unique student code. Please retry.", "STUDENT_CODE_GENERATION_FAILED");
      }
    }

    let createdLogin = null;
    if (shouldCreateLogin) {
      const passwordHash = await hashPassword(tempPassword);
      try {
        createdLogin = await tx.authUser.create({
          data: {
            tenantId: req.auth.tenantId,
            email: email ? String(email) : makeStudentPlaceholderEmail({ tenantId: req.auth.tenantId, studentId: student.id }),
            username: String(finalAdmissionNo),
            role: "STUDENT",
            passwordHash,
            isActive: true,
            mustChangePassword: true,
            studentId: student.id,
            parentUserId: req.auth.userId,
            hierarchyNodeId
          },
          select: { id: true, username: true, email: true }
        });
      } catch (err) {
        if (isUniqueConstraintError(err) && uniqueTargetsInclude(err, "email")) {
          throw makeApiError(409, "Email already used by another account", "AUTH_EMAIL_EXISTS");
        }
        if (isUniqueConstraintError(err) && uniqueTargetsInclude(err, "username")) {
          throw makeApiError(409, "Student code already used by another account", "AUTH_USERNAME_EXISTS");
        }
        throw err;
      }
    }

    await recordEnrollmentTransaction({
      tx,
      tenantId: req.auth.tenantId,
      studentId: student.id,
      actorUserId: req.auth.userId,
      grossAmount: enrollmentFeeAmount ?? 0
    });

    return { student, createdLogin, tempPassword };
  });

  res.locals.entityId = created.student.id;
  return res.apiSuccess(
    "Student created",
    {
      ...created.student,
      createdLogin: created.createdLogin,
      tempPassword: shouldCreateLogin ? created.tempPassword : null
    },
    201
  );
});

const updateStudent = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id } = req.params;
  const {
    admissionNo,
    firstName,
    lastName,
    email,
    dateOfBirth,
    guardianName,
    guardianPhone,
    guardianEmail,
    gender,
    phonePrimary,
    phoneSecondary,
    address,
    state,
    district,
    tehsil,
    totalFeeAmount,
    admissionFeeAmount,
    levelId,
    currentTeacherUserId,
    isActive
  } = req.body;

  const normalizedTotalFeeAmount = normalizeMoney(totalFeeAmount);
  if (normalizedTotalFeeAmount?.error) {
    return res.apiError(400, normalizedTotalFeeAmount.error, "VALIDATION_ERROR");
  }
  const normalizedAdmissionFeeAmount = normalizeMoney(admissionFeeAmount);
  if (normalizedAdmissionFeeAmount?.error) {
    return res.apiError(400, normalizedAdmissionFeeAmount.error, "VALIDATION_ERROR");
  }

  const existing = await prisma.student.findFirst({
    where: { id, tenantId: req.auth.tenantId },
    select: { id: true, hierarchyNodeId: true }
  });

  if (!existing) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId && existing.hierarchyNodeId !== req.auth.hierarchyNodeId) {
    return res.apiError(403, "Hierarchy scope denied", "HIERARCHY_SCOPE_DENIED");
  }

  const normalizedGender = gender !== undefined && gender !== null && gender !== ""
    ? String(gender).trim().toUpperCase()
    : null;

  if (normalizedGender && !["MALE", "FEMALE", "OTHER"].includes(normalizedGender)) {
    return res.apiError(400, "gender must be MALE, FEMALE, or OTHER", "VALIDATION_ERROR");
  }

  if (currentTeacherUserId !== undefined) {
    const nextTeacherId = currentTeacherUserId ? String(currentTeacherUserId) : null;
    if (nextTeacherId) {
      const teacher = await prisma.authUser.findFirst({
        where: {
          tenantId: req.auth.tenantId,
          id: nextTeacherId,
          role: "TEACHER",
          isActive: true,
          hierarchyNodeId: existing.hierarchyNodeId
        },
        select: { id: true }
      });

      if (!teacher) {
        return res.apiError(400, "currentTeacherUserId is not a valid active teacher for this center", "TEACHER_NOT_FOUND");
      }
    }
  }

  const updated = await prisma.student.update({
    where: { id },
    data: {
      ...(admissionNo !== undefined ? { admissionNo: String(admissionNo) } : {}),
      ...(firstName !== undefined ? { firstName: String(firstName) } : {}),
      ...(lastName !== undefined ? { lastName: String(lastName) } : {}),
      ...(email !== undefined ? { email: email ? String(email) : null } : {}),
      ...(dateOfBirth !== undefined ? { dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null } : {}),
      ...(guardianName !== undefined ? { guardianName: guardianName ? String(guardianName) : null } : {}),
      ...(guardianPhone !== undefined ? { guardianPhone: guardianPhone ? String(guardianPhone) : null } : {}),
      ...(guardianEmail !== undefined ? { guardianEmail: guardianEmail ? String(guardianEmail) : null } : {}),
      ...(gender !== undefined ? { gender: normalizedGender } : {}),
      ...(phonePrimary !== undefined ? { phonePrimary: phonePrimary ? String(phonePrimary) : null } : {}),
      ...(phoneSecondary !== undefined ? { phoneSecondary: phoneSecondary ? String(phoneSecondary) : null } : {}),
      ...(address !== undefined ? { address: address ? String(address) : null } : {}),
      ...(state !== undefined ? { state: state ? String(state) : null } : {}),
      ...(district !== undefined ? { district: district ? String(district) : null } : {}),
      ...(tehsil !== undefined ? { tehsil: tehsil ? String(tehsil) : null } : {}),
      ...(normalizedTotalFeeAmount !== undefined ? { totalFeeAmount: normalizedTotalFeeAmount } : {}),
      ...(normalizedAdmissionFeeAmount !== undefined ? { admissionFeeAmount: normalizedAdmissionFeeAmount } : {}),
      ...(levelId !== undefined ? { levelId: String(levelId) } : {}),
      ...(currentTeacherUserId !== undefined ? { currentTeacherUserId: currentTeacherUserId ? String(currentTeacherUserId) : null } : {}),
      ...(isActive !== undefined ? { isActive: Boolean(isActive) } : {})
    },
    include: {
      level: { select: { id: true, name: true, rank: true } },
      hierarchyNode: { select: { id: true, name: true, type: true } }
    }
  });

  res.locals.entityId = updated.id;
  return res.apiSuccess("Student updated", updated);
});

const uploadStudentPhoto = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id } = req.params;
  const file = req.file;
  if (!file?.filename) {
    return res.apiError(400, "file is required", "FILE_REQUIRED");
  }

  const url = `${req.protocol}://${req.get("host")}/uploads/student-photos/${file.filename}`;

  const updated = await prisma.student.update({
    where: { id },
    data: {
      photoUrl: url
    },
    select: { id: true, photoUrl: true }
  });

  res.locals.entityId = updated.id;
  return res.apiSuccess("Student photo uploaded", updated);
});

const createStudentFeePayment = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const studentId = String(req.params.id || "").trim();
  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const type = req.body?.type;
  const grossAmount = req.body?.grossAmount;
  const paymentMode = req.body?.paymentMode;
  const receivedAt = req.body?.receivedAt;
  const feeScheduleType = req.body?.feeScheduleType;
  const feeMonth = req.body?.feeMonth;
  const feeYear = req.body?.feeYear;
  const feeLevelId = req.body?.feeLevelId;
  const paymentReference = req.body?.paymentReference;
  const installmentId = req.body?.installmentId;

  // Ensure student exists and is in-scope (CENTER scope enforced by requireScopeAccess in route).
  const student = await prisma.student.findFirst({
    where: {
      id: studentId,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  const created = await prisma.$transaction((tx) =>
    recordStudentPaymentTransaction({
      tx,
      tenantId: req.auth.tenantId,
      studentId: student.id,
      actorUserId: req.auth.userId,
      type,
      grossAmount,
      paymentMode,
      receivedAt,
      feeScheduleType,
      feeMonth,
      feeYear,
      feeLevelId,
      paymentReference,
      installmentId
    })
  );

  res.locals.entityId = created.id;
  return res.apiSuccess("Payment recorded", created, 201);
});

const getStudentFeesContext = asyncHandler(async (req, res) => {
  const studentId = String(req.params.id || "").trim();
  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const student = await prisma.student.findFirst({
    where: {
      id: studentId,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      admissionNo: true,
      firstName: true,
      lastName: true,
      totalFeeAmount: true,
      admissionFeeAmount: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  const installments = await prisma.studentFeeInstallment.findMany({
    where: {
      tenantId: req.auth.tenantId,
      studentId: student.id
    },
    orderBy: [{ dueDate: "asc" }, { createdAt: "asc" }],
    select: {
      id: true,
      amount: true,
      dueDate: true,
      createdAt: true,
      updatedAt: true
    }
  });

  const payments = await prisma.financialTransaction.findMany({
    where: {
      tenantId: req.auth.tenantId,
      studentId: student.id,
      type: { in: ["ENROLLMENT", "RENEWAL", "ADJUSTMENT"] }
    },
    orderBy: { createdAt: "desc" },
    take: 200,
    select: {
      id: true,
      type: true,
      grossAmount: true,
      paymentMode: true,
      receivedAt: true,
      paymentReference: true,
      feeScheduleType: true,
      feeMonth: true,
      feeYear: true,
      feeLevelId: true,
      installmentId: true,
      createdAt: true,
      createdBy: { select: { id: true, username: true, email: true, role: true } },
      feeLevel: { select: { id: true, name: true, rank: true } },
      installment: { select: { id: true, dueDate: true, amount: true } }
    }
  });

  const paidTotal = payments.reduce((sum, p) => sum + Number(p.grossAmount || 0), 0);
  const totalFee = student.totalFeeAmount == null ? null : Number(student.totalFeeAmount);
  const pendingTotal = totalFee == null ? null : Math.max(0, Number((totalFee - paidTotal).toFixed(2)));

  const paidByInstallmentId = new Map();
  for (const payment of payments) {
    if (!payment.installmentId) continue;
    const prev = paidByInstallmentId.get(payment.installmentId) || 0;
    paidByInstallmentId.set(payment.installmentId, prev + Number(payment.grossAmount || 0));
  }

  const now = new Date();
  const installmentItems = installments.map((inst) => {
    const amount = Number(inst.amount || 0);
    const paid = Number((paidByInstallmentId.get(inst.id) || 0).toFixed(2));
    const pending = Math.max(0, Number((amount - paid).toFixed(2)));

    let status = "PENDING";
    if (paid >= amount && amount > 0) {
      status = "PAID";
    } else if (paid > 0) {
      status = "PARTIAL";
    } else if (inst.dueDate && inst.dueDate < now) {
      status = "OVERDUE";
    }

    return {
      ...inst,
      paid,
      pending,
      status
    };
  });

  return res.apiSuccess("Student fees context", {
    student: {
      id: student.id,
      admissionNo: student.admissionNo,
      fullName: `${student.firstName || ""} ${student.lastName || ""}`.trim(),
      totalFeeAmount: student.totalFeeAmount,
      admissionFeeAmount: student.admissionFeeAmount
    },
    summary: {
      totalFee,
      paid: Number(paidTotal.toFixed(2)),
      pending: pendingTotal,
      status: totalFee == null ? null : pendingTotal === 0 ? "PAID" : "PENDING"
    },
    installments: installmentItems,
    payments
  });
});

const upsertStudentInstallment = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const studentId = String(req.params.id || "").trim();
  if (!studentId) {
    return res.apiError(400, "studentId is required", "VALIDATION_ERROR");
  }

  const amount = Number(req.body?.amount);
  if (!Number.isFinite(amount) || amount <= 0) {
    return res.apiError(400, "amount must be > 0", "VALIDATION_ERROR");
  }

  const dueDateRaw = req.body?.dueDate;
  const dueDate = dueDateRaw ? new Date(dueDateRaw) : null;
  if (!dueDate || Number.isNaN(dueDate.getTime())) {
    return res.apiError(400, "dueDate must be a valid date", "VALIDATION_ERROR");
  }

  const created = await prisma.studentFeeInstallment.create({
    data: {
      tenantId: req.auth.tenantId,
      studentId,
      amount,
      dueDate
    },
    select: { id: true, amount: true, dueDate: true, createdAt: true }
  });

  res.locals.entityId = created.id;
  return res.apiSuccess("Installment created", created, 201);
});

const deleteStudentInstallment = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const studentId = String(req.params.id || "").trim();
  const installmentId = String(req.params.installmentId || "").trim();
  if (!studentId || !installmentId) {
    return res.apiError(400, "studentId and installmentId are required", "VALIDATION_ERROR");
  }

  const hasPayments = await prisma.financialTransaction.findFirst({
    where: {
      tenantId: req.auth.tenantId,
      studentId,
      installmentId
    },
    select: { id: true }
  });

  if (hasPayments) {
    return res.apiError(409, "Installment has payments; cannot delete", "INSTALLMENT_HAS_PAYMENTS");
  }

  await prisma.studentFeeInstallment.delete({
    where: { id: installmentId }
  });

  res.locals.entityId = installmentId;
  return res.apiSuccess("Installment deleted", { id: installmentId });
});

const createStudentLogin = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id } = req.params;
  const { password } = req.body;

  const student = await prisma.student.findFirst({
    where: { id, tenantId: req.auth.tenantId },
    select: {
      id: true,
      email: true,
      admissionNo: true,
      hierarchyNodeId: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId && student.hierarchyNodeId !== req.auth.hierarchyNodeId) {
    return res.apiError(403, "Hierarchy scope denied", "HIERARCHY_SCOPE_DENIED");
  }

  // Email is optional for student logins.

  const existingLogin = await prisma.authUser.findFirst({
    where: { tenantId: req.auth.tenantId, studentId: student.id },
    select: { id: true }
  });

  if (existingLogin) {
    return res.apiError(409, "Student login already exists", "STUDENT_LOGIN_EXISTS");
  }

  const tempPassword = String(password || student.admissionNo || "").trim();
  if (!tempPassword) {
    return res.apiError(400, "password (or admissionNo) is required", "STUDENT_PASSWORD_REQUIRED");
  }

  const passwordHash = await hashPassword(tempPassword);
  const login = await prisma.authUser.create({
    data: {
      tenantId: req.auth.tenantId,
      email: student.email || makeStudentPlaceholderEmail({ tenantId: req.auth.tenantId, studentId: student.id }),
      username: student.admissionNo,
      role: "STUDENT",
      passwordHash,
      isActive: true,
      mustChangePassword: true,
      studentId: student.id,
      parentUserId: req.auth.userId,
      hierarchyNodeId: student.hierarchyNodeId
    },
    select: { id: true, username: true, email: true }
  });

  res.locals.entityId = login.id;
  return res.apiSuccess("Student login created", { login, tempPassword }, 201);
});

const resetStudentPassword = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id } = req.params;
  const { newPassword, mustChangePassword } = req.body || {};

  const student = await prisma.student.findFirst({
    where: { id, tenantId: req.auth.tenantId },
    select: { id: true, hierarchyNodeId: true, admissionNo: true }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  if (req.auth.role !== "SUPERADMIN" && req.auth.hierarchyNodeId && student.hierarchyNodeId !== req.auth.hierarchyNodeId) {
    return res.apiError(403, "Hierarchy scope denied", "HIERARCHY_SCOPE_DENIED");
  }

  const login = await prisma.authUser.findFirst({
    where: { tenantId: req.auth.tenantId, studentId: student.id },
    select: { id: true, username: true, email: true }
  });

  if (!login) {
    return res.apiError(404, "Student login not found", "STUDENT_LOGIN_NOT_FOUND");
  }

  const trimmed = newPassword === undefined || newPassword === null ? "" : String(newPassword).trim();
  const tempPassword = trimmed || generateTempPassword();
  const passwordHash = await hashPassword(tempPassword);
  await prisma.authUser.update({
    where: { id: login.id },
    data: {
      passwordHash,
      mustChangePassword: mustChangePassword !== undefined ? Boolean(mustChangePassword) : true
    }
  });

  res.locals.entityId = login.id;
  return res.apiSuccess("Student password reset", {
    id: login.id,
    username: login.username,
    email: login.email,
    tempPassword: trimmed ? null : tempPassword
  });
});

const assignLevelToStudent = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id } = req.params;
  const { levelId } = req.body;

  const result = await assignLevelWithIntegrity({
    tenantId: req.auth.tenantId,
    studentId: id,
    targetLevelId: levelId,
    actorUserId: req.auth.userId,
    reason: "MANUAL_ASSIGNMENT"
  });

  const updated = await prisma.student.findUniqueOrThrow({
    where: { id },
    include: {
      level: { select: { id: true, name: true, rank: true } }
    }
  });

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "COURSE_ASSIGNMENT",
    entityType: "STUDENT",
    entityId: id,
    metadata: {
      assignedLevelId: levelId,
      previousLevelId: result.previousLevelId,
      changed: result.changed
    }
  });

  return res.apiSuccess("Level assigned to student", updated);
});

const getPromotionStatus = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const queryLevelId = req.query.levelId;

  const student = await prisma.student.findFirst({
    where: {
      id,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      levelId: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  const levelId = queryLevelId || student.levelId;
  const passState = await prisma.$transaction(async (tx) =>
    evaluatePassThreshold({
      tx,
      tenantId: req.auth.tenantId,
      studentId: id,
      levelId
    })
  );

  const eligibility = {
    eligible: passState.passed,
    reasons: passState.passed
      ? []
      : [`Score ${passState.score ?? "N/A"} below pass threshold ${passState.threshold}`],
    metrics: {
      threshold: passState.threshold,
      score: passState.score
    }
  };

  if (eligibility.eligible) {
    void (async () => {
      try {
        const studentContext = await prisma.student.findFirst({
          where: {
            id,
            tenantId: req.auth.tenantId
          },
          select: {
            hierarchyNodeId: true
          }
        });

        if (!studentContext) {
          return;
        }

        const recipients = await prisma.authUser.findMany({
          where: {
            tenantId: req.auth.tenantId,
            isActive: true,
            hierarchyNodeId: studentContext.hierarchyNodeId,
            role: {
              in: ["CENTER", "TEACHER"]
            }
          },
          select: {
            id: true
          }
        });

        await createBulkNotification(
          recipients.map((recipient) => ({
            tenantId: req.auth.tenantId,
            recipientUserId: recipient.id,
            type: "PROMOTION_READY",
            title: "Promotion Ready",
            message: `Student ${id} is eligible for promotion`,
            entityType: "STUDENT",
            entityId: id
          }))
        );
      } catch {
        return;
      }
    })();
  }

  return res.apiSuccess("Promotion eligibility calculated", {
    studentId: id,
    levelId,
    ...eligibility
  });
});

const getPerformanceSummary = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const queryLevelId = req.query.levelId;

  const student = await prisma.student.findFirst({
    where: {
      id,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      levelId: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  const levelId = queryLevelId || student.levelId;
  const performance = await getLevelPerformance(id, levelId, req.auth.tenantId);

  return res.apiSuccess("Performance summary calculated", performance);
});

const confirmPromotion = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id } = req.params;
  const student = await prisma.student.findFirst({
    where: {
      id,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      levelId: true
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  const currentLevel = await prisma.level.findFirst({
    where: {
      id: student.levelId,
      tenantId: req.auth.tenantId
    },
    select: {
      id: true,
      rank: true
    }
  });

  if (!currentLevel) {
    return res.apiError(404, "Current level not found", "CURRENT_LEVEL_NOT_FOUND");
  }

  const nextLevel = await prisma.level.findFirst({
    where: {
      tenantId: req.auth.tenantId,
      rank: currentLevel.rank + 1
    },
    select: {
      id: true
    }
  });

  if (!nextLevel) {
    return res.apiError(409, "Next level not found; cannot skip levels", "NEXT_LEVEL_NOT_FOUND");
  }

  const result = await assignLevelWithIntegrity({
    tenantId: req.auth.tenantId,
    studentId: id,
    targetLevelId: nextLevel.id,
    actorUserId: req.auth.userId,
    reason: "PROMOTION_CONFIRMED"
  });

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "PROMOTION_CONFIRMED",
    entityType: "STUDENT",
    entityId: id,
    metadata: {
      previousLevelId: result.previousLevelId,
      newLevelId: result.newLevelId,
      score: result.score,
      threshold: result.threshold
    }
  });

  void (async () => {
    try {
      const studentRecipients = await prisma.authUser.findMany({
        where: {
          tenantId: req.auth.tenantId,
          isActive: true,
          OR: [
            { studentId: id },
            {
              role: "TEACHER",
              hierarchyNodeId: (
                await prisma.student.findFirst({
                  where: { id, tenantId: req.auth.tenantId },
                  select: { hierarchyNodeId: true }
                })
              )?.hierarchyNodeId
            }
          ]
        },
        select: {
          id: true
        }
      });

      await createBulkNotification(
        studentRecipients.map((recipient) => ({
          tenantId: req.auth.tenantId,
          recipientUserId: recipient.id,
          type: "PROMOTION_CONFIRMED",
          title: "Promotion Confirmed",
          message: `Student ${id} promoted to next level`,
          entityType: "STUDENT",
          entityId: id
        }))
      );
    } catch {
      return;
    }
  })();

  return res.apiSuccess("Promotion confirmed", {
    success: true,
    previousLevelId: result.previousLevelId,
    newLevelId: result.newLevelId,
    promotedAt: new Date().toISOString(),
    score: result.score,
    threshold: result.threshold
  });
});

/**
 * Bulk CSV import of students.
 * Expected CSV columns: firstName, lastName, gender, dateOfBirth, guardianName, guardianPhone, guardianEmail, email, address
 * All rows share the request user's center (hierarchyNodeId) and lowest-rank level.
 */
const bulkImportStudentsCsv = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  if (!req.file || !req.file.buffer) {
    return res.apiError(400, "No CSV file uploaded", "FILE_REQUIRED");
  }

  const text = req.file.buffer.toString("utf-8").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = text.split("\n").filter((l) => l.trim().length > 0);

  if (lines.length < 2) {
    return res.apiError(400, "CSV must have a header row and at least one data row", "CSV_EMPTY");
  }

  const headerLine = lines[0];
  const headers = headerLine.split(",").map((h) => h.trim().toLowerCase().replace(/[^a-z0-9_]/g, ""));

  const dataLines = lines.slice(1);
  if (dataLines.length > 500) {
    return res.apiError(400, "Maximum 500 students per import", "CSV_TOO_LARGE");
  }

  const hierarchyNodeId = String(req.auth.hierarchyNodeId || "");
  if (!hierarchyNodeId) {
    return res.apiError(400, "hierarchyNodeId is required", "HIERARCHY_NODE_REQUIRED");
  }

  const defaultLevel = await prisma.level.findFirst({
    where: { tenantId: req.auth.tenantId },
    orderBy: { rank: "asc" },
    select: { id: true }
  });
  if (!defaultLevel) {
    return res.apiError(400, "No levels configured for tenant", "LEVELS_MISSING");
  }

  const results = { created: 0, errors: [] };

  for (let rowIdx = 0; rowIdx < dataLines.length; rowIdx += 1) {
    const line = dataLines[rowIdx];
    // Simple CSV split (does not handle quoted commas)
    const cells = line.split(",").map((c) => c.trim());
    const row = {};
    for (let i = 0; i < headers.length; i += 1) {
      row[headers[i]] = cells[i] || "";
    }

    const firstName = row.firstname || row.first_name || row.name || "";
    const lastName = row.lastname || row.last_name || "";

    if (!firstName) {
      results.errors.push({ row: rowIdx + 2, error: "firstName is required" });
      continue;
    }

    const normalizedGender = row.gender ? String(row.gender).trim().toUpperCase() : null;
    if (normalizedGender && !["MALE", "FEMALE", "OTHER"].includes(normalizedGender)) {
      results.errors.push({ row: rowIdx + 2, error: `Invalid gender: ${row.gender}` });
      continue;
    }

    let dob = null;
    if (row.dateofbirth || row.date_of_birth || row.dob) {
      try {
        dob = parseIsoDateOnly(row.dateofbirth || row.date_of_birth || row.dob);
      } catch {
        results.errors.push({ row: rowIdx + 2, error: "Invalid dateOfBirth format (use YYYY-MM-DD)" });
        continue;
      }
    }

    try {
      // eslint-disable-next-line no-await-in-loop
      await prisma.$transaction(async (tx) => {
        const admissionNo = await generateNextStudentCode({ tx, tenantId: req.auth.tenantId, prefix: "ST" });

        await tx.student.create({
          data: {
            tenantId: req.auth.tenantId,
            admissionNo,
            firstName,
            lastName: lastName || null,
            gender: normalizedGender || null,
            dateOfBirth: dob,
            guardianName: row.guardianname || row.guardian_name || null,
            guardianPhone: row.guardianphone || row.guardian_phone || null,
            guardianEmail: row.guardianemail || row.guardian_email || null,
            email: row.email || null,
            phonePrimary: row.guardianphone || row.guardian_phone || null,
            address: row.address || null,
            hierarchyNodeId,
            levelId: defaultLevel.id,
            isActive: true
          }
        });
      });

      results.created += 1;
    } catch (e) {
      const msg = e?.message || "Unknown error";
      results.errors.push({ row: rowIdx + 2, error: msg.slice(0, 200) });
    }
  }

  return res.apiSuccess("CSV import completed", {
    totalRows: dataLines.length,
    created: results.created,
    errorCount: results.errors.length,
    errors: results.errors.slice(0, 50)
  });
});

const assignCourseToStudent = asyncHandler(async (req, res) => {
  assertCanModifyOperational(req.auth.role);

  const { id } = req.params;
  const { courseId, courseIds } = req.body || {};

  const rawIds = Array.isArray(courseIds)
    ? courseIds
    : (courseId ? [courseId] : []);
  const normalizedCourseIds = [...new Set(rawIds
    .map((value) => String(value || "").trim())
    .filter(Boolean))];

  const student = await prisma.student.findFirst({
    where: { id, tenantId: req.auth.tenantId },
    select: {
      id: true,
      courseId: true,
      hierarchyNodeId: true,
      assignedCourses: {
        select: { courseId: true }
      }
    }
  });

  if (!student) {
    return res.apiError(404, "Student not found", "STUDENT_NOT_FOUND");
  }

  if (normalizedCourseIds.length > 0) {
    const courses = await prisma.course.findMany({
      where: {
        tenantId: req.auth.tenantId,
        id: { in: normalizedCourseIds },
        isActive: true
      },
      select: { id: true }
    });

    if (courses.length !== normalizedCourseIds.length) {
      return res.apiError(404, "One or more courses not found or inactive", "COURSE_NOT_FOUND");
    }
  }

  const updated = await prisma.$transaction(async (tx) => {
    await tx.studentAssignedCourse.deleteMany({
      where: {
        tenantId: req.auth.tenantId,
        studentId: id
      }
    });

    if (normalizedCourseIds.length > 0) {
      await tx.studentAssignedCourse.createMany({
        data: normalizedCourseIds.map((nextCourseId) => ({
          tenantId: req.auth.tenantId,
          studentId: id,
          courseId: nextCourseId
        }))
      });
    }

    return tx.student.update({
      where: { id },
      data: { courseId: normalizedCourseIds[0] || null },
      include: {
        level: { select: { id: true, name: true, rank: true } },
        course: { select: { id: true, code: true, name: true } },
        assignedCourses: {
          select: {
            id: true,
            courseId: true,
            course: { select: { id: true, code: true, name: true } }
          }
        }
      }
    });
  });

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "ASSIGN_COURSE",
    entityType: "STUDENT",
    entityId: id,
    metadata: {
      assignedCourseIds: normalizedCourseIds,
      assignedCourseId: normalizedCourseIds[0] || null,
      previousCourseId: student.courseId,
      previousCourseIds: Array.isArray(student.assignedCourses)
        ? student.assignedCourses.map((row) => row.courseId)
        : []
    }
  });

  return res.apiSuccess("Courses assigned to student", updated);
});

export {
  listStudents,
  getStudent,
  exportStudentsCsv,
  getNextStudentCode,
  listStudentNotes,
  createStudentNote,
  updateStudentNote,
  deleteStudentNote,
  exportStudentNotesCsv,
  createStudent,
  updateStudent,
  getStudentFeesContext,
  upsertStudentInstallment,
  deleteStudentInstallment,
  createStudentFeePayment,
  createStudentLogin,
  resetStudentPassword,
  assignLevelToStudent,
  assignCourseToStudent,
  getPromotionStatus,
  getPerformanceSummary,
  confirmPromotion,
  uploadStudentPhoto,
  bulkImportStudentsCsv
};
