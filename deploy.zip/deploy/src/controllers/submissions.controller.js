import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";
import { parsePagination } from "../utils/pagination.js";

const listSubmissions = asyncHandler(async (req, res) => {
  const { take, skip, orderBy } = parsePagination(req.query);

  const where = {
    tenantId: req.auth.tenantId
  };

  const data = await prisma.worksheetSubmission.findMany({
    where,
    orderBy,
    skip,
    take,
    select: {
      id: true,
      tenantId: true,
      worksheetId: true,
      studentId: true,
      score: true,
      status: true,
      submittedAt: true,
      createdAt: true,
      finalSubmittedAt: true,
      passed: true,
      remarks: true,
      student: {
        select: {
          id: true,
          admissionNo: true,
          firstName: true,
          lastName: true,
          hierarchyNodeId: true,
          levelId: true
        }
      },
      worksheet: {
        select: {
          id: true,
          title: true,
          levelId: true,
          difficulty: true
        }
      }
    }
  });

  return res.apiSuccess("Submissions fetched", data);
});

export { listSubmissions };