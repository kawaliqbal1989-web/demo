import { prisma } from "../lib/prisma.js";
import { asyncHandler } from "../utils/async-handler.js";
import { hashPassword } from "../utils/password.js";
import { safelyUpdateUserRole } from "../services/superadmin-guard.service.js";
import { recordAudit } from "../utils/audit.js";
import { generateUsername } from "../utils/username-generator.js";
import { parsePagination } from "../utils/pagination.js";

const listSuperadmins = asyncHandler(async (req, res) => {
  const data = await prisma.superadmin.findMany({
    where: {
      tenantId: req.auth.tenantId
    },
    orderBy: { createdAt: "desc" },
    select: { id: true, email: true, fullName: true, isActive: true, createdAt: true }
  });

  return res.apiSuccess("Superadmins fetched", data);
});

const createSuperadmin = asyncHandler(async (req, res) => {
  const { email, password, fullName } = req.body;

  if (!email || !password || !fullName) {
    return res.apiError(400, "email, password and fullName are required", "VALIDATION_ERROR");
  }

  const generatedHash = await hashPassword(password);

  const created = await prisma.$transaction(async (tx) => {
    const username = await generateUsername({
      tx,
      tenantId: req.auth.tenantId,
      role: "SUPERADMIN"
    });

    const authUser = await tx.authUser.create({
      data: {
        username,
        email,
        passwordHash: generatedHash,
        role: "SUPERADMIN",
        tenantId: req.auth.tenantId,
        parentUserId: req.auth.userId
      }
    });

    const superadmin = await tx.superadmin.create({
      data: {
        tenantId: req.auth.tenantId,
        email,
        fullName,
        authUserId: authUser.id
      },
      select: { id: true, email: true, fullName: true, isActive: true, createdAt: true }
    });

    return superadmin;
  });

  res.locals.entityId = created.id;
  return res.apiSuccess("Superadmin created", created, 201);
});

const listUsersByRole = asyncHandler(async (req, res) => {
  const { take, skip, limit, offset, orderBy } = parsePagination(req.query);
  const role = req.query.role ? String(req.query.role) : null;
  const q = req.query.q ? String(req.query.q).trim() : null;
  const status = req.query.status ? String(req.query.status).trim().toUpperCase() : null;
  const parentId = req.query.parentId ? String(req.query.parentId).trim() : null;

  if (!role) {
    return res.apiError(400, "role query parameter is required", "VALIDATION_ERROR");
  }

  const where = {
    tenantId: req.auth.tenantId,
    role: role.toUpperCase(),
    isActive: true
  };

  const hierarchyNodeIs = {};

  if (parentId) {
    hierarchyNodeIs.parentId = parentId;
  }

  if (q) {
    where.OR = [
      { username: { contains: q } },
      { email: { contains: q } },
      {
        hierarchyNode: {
          is: {
            name: { contains: q }
          }
        }
      },
      {
        hierarchyNode: {
          is: {
            code: { contains: q }
          }
        }
      },
      {
        hierarchyNode: {
          is: {
            parent: {
              is: {
                name: { contains: q }
              }
            }
          }
        }
      },
      {
        hierarchyNode: {
          is: {
            parent: {
              is: {
                code: { contains: q }
              }
            }
          }
        }
      }
    ];
  }

  if (status === "ACTIVE") {
    hierarchyNodeIs.isActive = true;
  }

  if (status === "INACTIVE") {
    hierarchyNodeIs.isActive = false;
  }

  if (Object.keys(hierarchyNodeIs).length) {
    where.hierarchyNode = { is: hierarchyNodeIs };
  }

  const items = await prisma.authUser.findMany({
    where,
    orderBy,
    skip,
    take,
    select: {
      id: true,
      username: true,
      email: true,
      role: true,
      hierarchyNodeId: true,
      createdAt: true,
      hierarchyNode: {
        select: {
          id: true,
          code: true,
          name: true,
          type: true,
          isActive: true,
          parent: {
            select: {
              id: true,
              code: true,
              name: true,
              type: true,
              parent: {
                select: {
                  id: true,
                  code: true,
                  name: true,
                  type: true
                }
              }
            }
          }
        }
      }
    }
  });

  return res.apiSuccess("Users fetched", {
    items,
    limit,
    offset
  });
});

const updateUserRole = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { role } = req.body;

  if (!role) {
    return res.apiError(400, "role is required", "VALIDATION_ERROR");
  }

  const updated = await prisma.$transaction(async (tx) => {
    return safelyUpdateUserRole({
      tx,
      actor: {
        userId: req.auth.userId,
        role: req.auth.role,
        tenantId: req.auth.tenantId
      },
      targetUserId: id,
      targetNewRole: role
    });
  });

  await recordAudit({
    tenantId: req.auth.tenantId,
    userId: req.auth.userId,
    role: req.auth.role,
    action: "ROLE_UPDATE",
    entityType: "AUTH_USER",
    entityId: updated.id,
    metadata: {
      newRole: updated.role
    }
  }, { strict: true });

  return res.apiSuccess("User role updated", updated);
});

function decimalToNumber(value) {
  if (value === null || value === undefined) {
    return 0;
  }

  if (typeof value === "number") {
    return value;
  }

  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  // Prisma Decimal.js
  if (typeof value?.toNumber === "function") {
    return value.toNumber();
  }

  const parsed = Number(String(value));
  return Number.isFinite(parsed) ? parsed : 0;
}

const getKpis = asyncHandler(async (req, res) => {
  const tenantId = req.auth.tenantId;
  const now = new Date();
  const since24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const [
    activeBusinessPartners,
    activeStudents,
    centerUsers,
    franchiseUsers,
    activeCompetitions,
    pendingCompetitionApprovals,
    openAbuseFlags,
    auditEventsLast24h,
    revenueMtdAgg
  ] = await Promise.all([
    prisma.businessPartner.count({
      where: {
        tenantId,
        status: "ACTIVE",
        isActive: true
      }
    }),
    prisma.student.count({
      where: {
        tenantId,
        isActive: true
      }
    }),
    prisma.authUser.count({
      where: {
        tenantId,
        role: "CENTER",
        isActive: true
      }
    }),
    prisma.authUser.count({
      where: {
        tenantId,
        role: "FRANCHISE",
        isActive: true
      }
    }),
    prisma.competition.count({
      where: {
        tenantId,
        status: "ACTIVE"
      }
    }),
    prisma.competition.count({
      where: {
        tenantId,
        workflowStage: "SUPERADMIN_APPROVAL",
        status: { in: ["DRAFT", "SCHEDULED", "ACTIVE"] }
      }
    }),
    prisma.abuseFlag.count({
      where: {
        tenantId,
        resolvedAt: null
      }
    }),
    prisma.auditLog.count({
      where: {
        tenantId,
        createdAt: { gte: since24h }
      }
    }),
    prisma.financialTransaction.aggregate({
      where: {
        tenantId,
        createdAt: { gte: monthStart }
      },
      _sum: {
        grossAmount: true
      }
    })
  ]);

  return res.apiSuccess("KPIs fetched", {
    asOf: now.toISOString(),
    tenantId,
    health: {
      uptimeSeconds: Math.round(process.uptime()),
      db: "ok"
    },
    metrics: {
      activeBusinessPartners,
      activeStudents,
      activeCenterUsers: centerUsers,
      activeFranchiseUsers: franchiseUsers,
      activeCompetitions,
      pendingCompetitionApprovals,
      openAbuseFlags,
      auditEventsLast24h,
      grossRevenueMtd: decimalToNumber(revenueMtdAgg?._sum?.grossAmount)
    }
  });
});

const recordDashboardAction = asyncHandler(async (req, res) => {
  const actionType = req.body?.actionType ? String(req.body.actionType).trim() : null;
  if (!actionType) {
    return res.apiError(400, "actionType is required", "VALIDATION_ERROR");
  }

  const metadata = req.body?.metadata && typeof req.body.metadata === "object" ? req.body.metadata : null;
  res.locals.auditMetadata = {
    actionType,
    ...(metadata ? { clientMetadata: metadata } : {})
  };

  return res.apiSuccess("Dashboard action recorded", { actionType }, 201);
});

export {
  listSuperadmins,
  createSuperadmin,
  updateUserRole,
  listUsersByRole,
  getKpis,
  recordDashboardAction
};
