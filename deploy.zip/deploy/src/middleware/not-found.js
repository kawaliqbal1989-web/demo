function notFoundHandler(req, res) {
  res.apiError(404, `Route not found: ${req.method} ${req.originalUrl}`, "ROUTE_NOT_FOUND");
}

export { notFoundHandler };
