import { Router } from "express";
import { requireRole } from "../middleware/rbac.js";
import { auditAction } from "../middleware/audit-logger.js";
import {
  getCenterMe,
  getCenterDashboard,
  listCenterAvailableCourses,
  getCenterAssignWorksheetsContext,
  listMockTests,
  createMockTest,
  updateMockTestStatus,
  getMockTest,
  saveCenterWorksheetAssignments,
  upsertMockTestResults
} from "../controllers/center.controller.js";

const centerRouter = Router();

centerRouter.use(requireRole("CENTER"));

centerRouter.get("/me", auditAction("CENTER_VIEW_PROFILE", "CENTER"), getCenterMe);
centerRouter.get("/dashboard", auditAction("CENTER_VIEW_DASHBOARD", "CENTER"), getCenterDashboard);

centerRouter.get(
  "/available-courses",
  auditAction("CENTER_VIEW_AVAILABLE_COURSES", "COURSE"),
  listCenterAvailableCourses
);

centerRouter.get(
  "/students/:studentId/assign-worksheets",
  auditAction("CENTER_VIEW_ASSIGN_WORKSHEETS", "STUDENT", (req) => req.params.studentId),
  getCenterAssignWorksheetsContext
);

centerRouter.post(
  "/students/:studentId/assign-worksheets",
  auditAction("CENTER_SAVE_ASSIGN_WORKSHEETS", "STUDENT", (req) => req.params.studentId),
  saveCenterWorksheetAssignments
);

centerRouter.get("/mock-tests", auditAction("CENTER_LIST_MOCK_TESTS", "MOCK_TEST"), listMockTests);
centerRouter.post("/mock-tests", auditAction("CENTER_CREATE_MOCK_TEST", "MOCK_TEST"), createMockTest);
centerRouter.get("/mock-tests/:id", auditAction("CENTER_VIEW_MOCK_TEST", "MOCK_TEST", (req) => req.params.id), getMockTest);
centerRouter.patch(
  "/mock-tests/:id/status",
  auditAction("CENTER_UPDATE_MOCK_TEST_STATUS", "MOCK_TEST", (req) => req.params.id),
  updateMockTestStatus
);
centerRouter.put(
  "/mock-tests/:id/results",
  auditAction("CENTER_SAVE_MOCK_TEST_RESULTS", "MOCK_TEST", (req) => req.params.id),
  upsertMockTestResults
);

export { centerRouter };
