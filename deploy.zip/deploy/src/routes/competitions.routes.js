import { Router } from "express";
import {
  createCompetition,
  enrollStudent,
  exportCompetitionResultsCsv,
  forwardCompetitionRequest,
  rejectCompetitionRequest,
  getLeaderboard,
  listCompetitions
} from "../controllers/competitions.controller.js";
import { requireOperationalRoles, requireRole } from "../middleware/rbac.js";
import { requireScopeAccess } from "../middleware/scope-access.js";
import { auditAction } from "../middleware/audit-logger.js";

const competitionsRouter = Router();

competitionsRouter.get("/", requireOperationalRoles(), listCompetitions);
competitionsRouter.post(
  "/",
  requireRole("BP", "FRANCHISE", "CENTER", "SUPERADMIN"),
  auditAction("CREATE_COMPETITION", "COMPETITION"),
  createCompetition
);

competitionsRouter.post(
  "/:id/enrollments",
  requireRole("CENTER", "FRANCHISE", "BP", "SUPERADMIN"),
  requireScopeAccess("competition", "id"),
  auditAction("ENROLL_STUDENT_COMPETITION", "COMPETITION", (req) => req.params.id),
  enrollStudent
);

competitionsRouter.post(
  "/:id/forward-request",
  requireRole("CENTER", "FRANCHISE", "BP", "SUPERADMIN"),
  requireScopeAccess("competition", "id"),
  auditAction("FORWARD_COMPETITION_REQUEST", "COMPETITION", (req) => req.params.id),
  forwardCompetitionRequest
);

competitionsRouter.post(
  "/:id/reject",
  requireRole("CENTER", "FRANCHISE", "BP", "SUPERADMIN"),
  requireScopeAccess("competition", "id"),
  auditAction("REJECT_COMPETITION_REQUEST", "COMPETITION", (req) => req.params.id),
  rejectCompetitionRequest
);

competitionsRouter.get(
  "/:id/leaderboard",
  requireOperationalRoles(),
  requireScopeAccess("competition", "id"),
  getLeaderboard
);

competitionsRouter.get(
  "/:id/results.csv",
  requireOperationalRoles(),
  requireScopeAccess("competition", "id"),
  exportCompetitionResultsCsv
);

export { competitionsRouter };
