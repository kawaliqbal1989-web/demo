import { Router } from "express";
import { requireRole } from "../middleware/rbac.js";
import { auditAction } from "../middleware/audit-logger.js";
import { requireBusinessPartnerScope } from "../middleware/partner-scope.js";
import {
  exportPartnerStudentsCsv,
  getPartnerDashboard,
  listPartnerStudents,
  listPartnerCertificates,
  issuePartnerCertificate,
  revokePartnerCertificate,
  exportPartnerCertificatesCsv,
  getPartnerProfile,
  updatePartnerProfile,
  listPartnerCourses,
  listPartnerHierarchy,
  listPartnerCompetitionRequests,
  submitPartnerCompetitionRequest,
  forwardPartnerCompetitionRequest
} from "../controllers/partner.controller.js";

const partnerRouter = Router();

partnerRouter.use(requireRole("BP"));
partnerRouter.use(requireBusinessPartnerScope);

partnerRouter.get(
  "/dashboard",
  auditAction("BP_VIEW_DASHBOARD", "BUSINESS_PARTNER"),
  getPartnerDashboard
);

partnerRouter.get(
  "/profile",
  auditAction("BP_VIEW_PROFILE", "BUSINESS_PARTNER"),
  getPartnerProfile
);

partnerRouter.patch(
  "/profile",
  auditAction("BP_UPDATE_PROFILE", "BUSINESS_PARTNER"),
  updatePartnerProfile
);

partnerRouter.get(
  "/students",
  auditAction("BP_VIEW_STUDENTS", "STUDENT"),
  listPartnerStudents
);

partnerRouter.get(
  "/students/export.csv",
  auditAction("BP_EXPORT_STUDENTS", "STUDENT"),
  exportPartnerStudentsCsv
);

partnerRouter.get(
  "/certificates",
  auditAction("BP_VIEW_CERTIFICATES", "CERTIFICATE"),
  listPartnerCertificates
);

partnerRouter.get(
  "/certificates/export.csv",
  auditAction("BP_EXPORT_CERTIFICATES", "CERTIFICATE"),
  exportPartnerCertificatesCsv
);

partnerRouter.post(
  "/certificates",
  auditAction("BP_ISSUE_CERTIFICATE", "CERTIFICATE"),
  issuePartnerCertificate
);

partnerRouter.patch(
  "/certificates/:id/revoke",
  auditAction("BP_REVOKE_CERTIFICATE", "CERTIFICATE", (req) => req.params.id),
  revokePartnerCertificate
);

partnerRouter.get(
  "/courses",
  auditAction("BP_VIEW_COURSES", "COURSE"),
  listPartnerCourses
);

partnerRouter.get(
  "/hierarchy",
  auditAction("BP_VIEW_HIERARCHY", "HIERARCHY_NODE"),
  listPartnerHierarchy
);

partnerRouter.get(
  "/competition_requests",
  auditAction("BP_VIEW_COMPETITION_REQUESTS", "COMPETITION"),
  listPartnerCompetitionRequests
);

partnerRouter.post(
  "/competition_requests",
  auditAction("BP_SUBMIT_COMPETITION_REQUEST", "COMPETITION"),
  submitPartnerCompetitionRequest
);

partnerRouter.post(
  "/competition_requests/:id/forward",
  auditAction("BP_FORWARD_COMPETITION_REQUEST", "COMPETITION", (req) => req.params.id),
  forwardPartnerCompetitionRequest
);

export { partnerRouter };
