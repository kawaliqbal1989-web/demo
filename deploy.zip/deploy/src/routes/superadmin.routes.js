import { Router } from "express";
import {
  createSuperadmin,
  getKpis,
  listSuperadmins,
  recordDashboardAction,
  updateUserRole,
  listUsersByRole
} from "../controllers/superadmin.controller.js";
import { requireSuperadmin } from "../middleware/rbac.js";
import { auditAction } from "../middleware/audit-logger.js";
import { kpiRateLimiter } from "../middleware/kpi-rate-limit.js";

const superadminRouter = Router();

superadminRouter.get("/", requireSuperadmin(), listSuperadmins);
superadminRouter.get("/users", requireSuperadmin(), listUsersByRole);

superadminRouter.get(
  "/kpis",
  requireSuperadmin(),
  kpiRateLimiter,
  auditAction("VIEW_SUPERADMIN_KPIS", "DASHBOARD"),
  getKpis
);

superadminRouter.post(
  "/dashboard/actions",
  requireSuperadmin(),
  auditAction("SUPERADMIN_DASHBOARD_ACTION", "DASHBOARD"),
  recordDashboardAction
);
superadminRouter.post(
  "/",
  requireSuperadmin(),
  auditAction("CREATE_SUPERADMIN", "SUPERADMIN"),
  createSuperadmin
);

superadminRouter.patch(
  "/:id/role",
  requireSuperadmin(),
  auditAction("ROLE_UPDATE", "AUTH_USER", (req) => req.params.id),
  updateUserRole
);

export { superadminRouter };
