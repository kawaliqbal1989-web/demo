import { Router } from "express";
import { teacherLogin } from "../controllers/teacher-portal.controller.js";

const teacherPublicRouter = Router();

teacherPublicRouter.post("/login", teacherLogin);

export { teacherPublicRouter };
