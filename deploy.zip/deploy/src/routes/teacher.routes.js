import { Router } from "express";
import { requireRole } from "../middleware/rbac.js";
import { auditAction } from "../middleware/audit-logger.js";
import {
  getTeacherMe,
  updateTeacherProfile,
  listTeacherBatches,
  getTeacherBatchRoster,
  listTeacherStudents,
  getTeacherStudent,
  listTeacherStudentMaterials,
  getTeacherStudentPracticeReport,
  listTeacherStudentAttempts,
  exportTeacherStudentAttemptsCsv,
  overrideTeacherStudentPromotion,
  getTeacherAssignWorksheetsContext,
  saveTeacherWorksheetAssignments,
  getTeacherBatchWorksheetsContext,
  assignTeacherBatchWorksheet,
  listTeacherBatchMockTests,
  getTeacherMockTest,
  upsertTeacherMockTestResults,
  listTeacherNotesForStudent,
  createTeacherNoteForStudent,
  updateTeacherNote,
  deleteTeacherNote,
  createTeacherAttendanceSession,
  listTeacherAttendanceSessions,
  getTeacherAttendanceSession,
  updateTeacherAttendanceEntries,
  publishTeacherAttendanceSession
} from "../controllers/teacher-portal.controller.js";

const teacherRouter = Router();

teacherRouter.use(requireRole("TEACHER"));

teacherRouter.get("/me", getTeacherMe);

teacherRouter.patch(
  "/profile",
  auditAction("TEACHER_UPDATE_PROFILE", "TEACHER"),
  updateTeacherProfile
);

teacherRouter.get("/batches", listTeacherBatches);
teacherRouter.get("/batches/:batchId/roster", getTeacherBatchRoster);
teacherRouter.get(
  "/batches/:batchId/worksheets/context",
  auditAction("TEACHER_VIEW_BATCH_WORKSHEET_CONTEXT", "BATCH", (req) => req.params.batchId),
  getTeacherBatchWorksheetsContext
);
teacherRouter.post(
  "/batches/:batchId/worksheets/assign",
  auditAction("TEACHER_ASSIGN_BATCH_WORKSHEET", "BATCH", (req) => req.params.batchId),
  assignTeacherBatchWorksheet
);
teacherRouter.get(
  "/batches/:batchId/mock-tests",
  auditAction("TEACHER_LIST_BATCH_MOCK_TESTS", "BATCH", (req) => req.params.batchId),
  listTeacherBatchMockTests
);
teacherRouter.get(
  "/mock-tests/:mockTestId",
  auditAction("TEACHER_VIEW_MOCK_TEST", "MOCK_TEST", (req) => req.params.mockTestId),
  getTeacherMockTest
);
teacherRouter.put(
  "/mock-tests/:mockTestId/results",
  auditAction("TEACHER_SAVE_MOCK_TEST_RESULTS", "MOCK_TEST", (req) => req.params.mockTestId),
  upsertTeacherMockTestResults
);

teacherRouter.get("/students", listTeacherStudents);
teacherRouter.get("/students/:studentId", getTeacherStudent);
teacherRouter.get("/students/:studentId/materials", listTeacherStudentMaterials);
teacherRouter.get("/students/:studentId/practice-report", getTeacherStudentPracticeReport);
teacherRouter.get("/students/:studentId/attempts/export.csv", exportTeacherStudentAttemptsCsv);
teacherRouter.get("/students/:studentId/attempts", listTeacherStudentAttempts);
teacherRouter.post(
  "/students/:studentId/override-promotion",
  auditAction("TEACHER_OVERRIDE_PROMOTION", "STUDENT", (req) => req.params.studentId),
  overrideTeacherStudentPromotion
);
teacherRouter.get(
  "/students/:studentId/assign-worksheets",
  auditAction("TEACHER_VIEW_ASSIGN_WORKSHEETS", "STUDENT", (req) => req.params.studentId),
  getTeacherAssignWorksheetsContext
);
teacherRouter.post(
  "/students/:studentId/assign-worksheets",
  auditAction("TEACHER_SAVE_ASSIGN_WORKSHEETS", "STUDENT", (req) => req.params.studentId),
  saveTeacherWorksheetAssignments
);

teacherRouter.get("/students/:studentId/notes", listTeacherNotesForStudent);
teacherRouter.post(
  "/students/:studentId/notes",
  auditAction("TEACHER_NOTE_CREATE", "TEACHER_NOTE"),
  createTeacherNoteForStudent
);
teacherRouter.put(
  "/notes/:noteId",
  auditAction("TEACHER_NOTE_UPDATE", "TEACHER_NOTE", (req) => req.params.noteId),
  updateTeacherNote
);
teacherRouter.delete(
  "/notes/:noteId",
  auditAction("TEACHER_NOTE_DELETE", "TEACHER_NOTE", (req) => req.params.noteId),
  deleteTeacherNote
);

teacherRouter.post(
  "/attendance/sessions",
  auditAction("TEACHER_ATTENDANCE_CREATE_SESSION", "ATTENDANCE_SESSION"),
  createTeacherAttendanceSession
);
teacherRouter.get("/attendance/sessions", listTeacherAttendanceSessions);
teacherRouter.get("/attendance/sessions/:sessionId", getTeacherAttendanceSession);
teacherRouter.put(
  "/attendance/sessions/:sessionId/entries",
  auditAction("TEACHER_ATTENDANCE_UPDATE_ENTRIES", "ATTENDANCE_SESSION", (req) => req.params.sessionId),
  updateTeacherAttendanceEntries
);
teacherRouter.post(
  "/attendance/sessions/:sessionId/publish",
  auditAction("TEACHER_ATTENDANCE_PUBLISH", "ATTENDANCE_SESSION", (req) => req.params.sessionId),
  publishTeacherAttendanceSession
);

export { teacherRouter };
