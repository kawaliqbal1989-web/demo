import { prisma } from "../lib/prisma.js";

function getDb(dbClient) {
  return dbClient || prisma;
}

async function createNotification(payload, dbClient) {
  const db = getDb(dbClient);

  const created = await db.notification.create({
    data: {
      tenantId: payload.tenantId,
      recipientUserId: payload.recipientUserId,
      type: payload.type,
      title: payload.title,
      message: payload.message,
      entityType: payload.entityType || null,
      entityId: payload.entityId || null
    },
    select: {
      id: true,
      type: true,
      title: true,
      message: true,
      isRead: true,
      createdAt: true
    }
  });

  return created;
}

async function createBulkNotification(payloads, dbClient) {
  if (!Array.isArray(payloads) || !payloads.length) {
    return { count: 0 };
  }

  const db = getDb(dbClient);
  const result = await db.notification.createMany({
    data: payloads.map((payload) => ({
      tenantId: payload.tenantId,
      recipientUserId: payload.recipientUserId,
      type: payload.type,
      title: payload.title,
      message: payload.message,
      entityType: payload.entityType || null,
      entityId: payload.entityId || null
    }))
  });

  return result;
}

async function markAsRead(notificationId, userId, tenantId, dbClient) {
  const db = getDb(dbClient);

  const existing = await db.notification.findFirst({
    where: {
      id: notificationId,
      recipientUserId: userId,
      tenantId
    },
    select: {
      id: true,
      isRead: true,
      createdAt: true,
      type: true,
      title: true,
      message: true
    }
  });

  if (!existing) {
    const error = new Error("Notification not found");
    error.statusCode = 404;
    error.errorCode = "NOTIFICATION_NOT_FOUND";
    throw error;
  }

  if (existing.isRead) {
    return existing;
  }

  const updated = await db.notification.update({
    where: {
      id: notificationId
    },
    data: {
      isRead: true
    },
    select: {
      id: true,
      type: true,
      title: true,
      message: true,
      isRead: true,
      createdAt: true
    }
  });

  return updated;
}

async function markAllAsRead(userId, tenantId, dbClient) {
  const db = getDb(dbClient);

  return db.notification.updateMany({
    where: {
      recipientUserId: userId,
      tenantId,
      isRead: false
    },
    data: {
      isRead: true
    }
  });
}

async function getUserNotifications(userId, tenantId, filters = {}, dbClient) {
  const db = getDb(dbClient);
  const page = Math.max(1, Number(filters.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(filters.limit) || 20));
  const skip = (page - 1) * limit;

  const where = {
    recipientUserId: userId,
    tenantId
  };

  if (String(filters.unread) === "true") {
    where.isRead = false;
  }

  const [total, items] = await Promise.all([
    db.notification.count({ where }),
    db.notification.findMany({
      where,
      orderBy: {
        createdAt: "desc"
      },
      skip,
      take: limit,
      select: {
        id: true,
        type: true,
        title: true,
        message: true,
        isRead: true,
        createdAt: true
      }
    })
  ]);

  return {
    page,
    limit,
    total,
    items
  };
}

async function findUsersByRoles(tenantId, roles, hierarchyNodeId = null, dbClient) {
  const db = getDb(dbClient);
  return db.authUser.findMany({
    where: {
      tenantId,
      isActive: true,
      role: {
        in: roles
      },
      ...(hierarchyNodeId ? { hierarchyNodeId } : {})
    },
    select: {
      id: true,
      role: true
    }
  });
}

export {
  createNotification,
  createBulkNotification,
  markAsRead,
  markAllAsRead,
  getUserNotifications,
  findUsersByRoles
};
